import os
import glob
import time
import torch
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from tqdm import tqdm
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import segmentation_models_pytorch as smp

# =========================
# CONFIGURATION SECTION
# =========================
CONFIG = {
    "data_dir": "dataset",
    "images_dir": "dataset/png_images",
    "masks_dir": "dataset/png_masks",
    "img_size": 256,
    "batch_size": 8,
    "num_epochs": 10,
    "learning_rate": 1e-4,
    "val_split": 0.2,
    "device": "cuda" if torch.cuda.is_available() else "cpu",
    "train_unet": True,
    "train_unetpp": True,
    "train_nnunet": True
}
os.makedirs("checkpoints", exist_ok=True)

# =========================
# DATASET CLASS
# =========================
class SIIMDataset(Dataset):
    def __init__(self, img_files, mask_files, transform=None):
        self.img_files = img_files
        self.mask_files = mask_files
        self.transform = transform

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        img = Image.open(self.img_files[idx]).convert("RGB")
        mask = Image.open(self.mask_files[idx]).convert("L")

        img = img.resize((CONFIG["img_size"], CONFIG["img_size"]))
        mask = mask.resize((CONFIG["img_size"], CONFIG["img_size"]))

        img = np.array(img).astype(np.float32) / 255.0
        mask = np.array(mask).astype(np.float32) / 255.0
        mask = (mask > 0.5).astype(np.float32)

        if self.transform:
            img = self.transform(img)

        mask = torch.tensor(mask, dtype=torch.float32).unsqueeze(0)
        return img.float(), mask.float()

# =========================
# HELPER FUNCTIONS
# =========================
def dice_score(pred, target, smooth=1e-6):
    pred = pred.view(-1)
    target = target.view(-1)
    intersection = (pred * target).sum()
    return (2. * intersection + smooth) / (pred.sum() + target.sum() + smooth)

def iou_score(pred, target, smooth=1e-6):
    pred = pred.view(-1)
    target = target.view(-1)
    intersection = (pred * target).sum()
    union = pred.sum() + target.sum() - intersection
    return (intersection + smooth) / (union + smooth)

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def model_size_mb(model):
    torch.save(model.state_dict(), "temp.pth")
    size = os.path.getsize("temp.pth") / (1024 * 1024)
    os.remove("temp.pth")
    return size

# =========================
# TRAINING FUNCTION
# =========================
def train_model(model, train_loader, val_loader, model_name):
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=CONFIG["learning_rate"])

    best_val_dice = 0
    history = {"train_loss": [], "val_loss": [], "val_dice": [], "val_acc": []}
    start_time = time.time()

    for epoch in range(CONFIG["num_epochs"]):
        model.train()
        running_loss = 0.0
        loop = tqdm(train_loader, desc=f"{model_name} Epoch [{epoch+1}/{CONFIG['num_epochs']}]", leave=False)

        for imgs, masks in loop:
            imgs, masks = imgs.to(CONFIG["device"]), masks.to(CONFIG["device"])

            optimizer.zero_grad()
            outputs = model(imgs)
            if isinstance(outputs, dict):
                outputs = outputs["out"]
            loss = criterion(outputs, masks)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            loop.set_postfix(loss=loss.item())

        avg_loss = running_loss / len(train_loader)

        # Validation
        model.eval()
        val_loss, dice_scores, y_true, y_pred = 0.0, [], [], []
        with torch.no_grad():
            for imgs, masks in val_loader:
                imgs, masks = imgs.to(CONFIG["device"]), masks.to(CONFIG["device"])
                outputs = model(imgs)
                if isinstance(outputs, dict):
                    outputs = outputs["out"]
                val_loss += criterion(outputs, masks).item()

                preds = (torch.sigmoid(outputs) > 0.5).float()
                for i in range(len(preds)):
                    dice_scores.append(dice_score(preds[i], masks[i]).item())
                    gt_cls = int(masks[i].sum() > 0)
                    pr_cls = int(preds[i].sum() > 0)
                    y_true.append(gt_cls)
                    y_pred.append(pr_cls)

        val_loss /= len(val_loader)
        avg_dice = np.mean(dice_scores)
        acc = accuracy_score(y_true, y_pred)

        history["train_loss"].append(avg_loss)
        history["val_loss"].append(val_loss)
        history["val_dice"].append(avg_dice)
        history["val_acc"].append(acc)

        tqdm.write(f"{model_name} Epoch {epoch+1}: Train Loss={avg_loss:.4f}, Val Loss={val_loss:.4f}, Dice={avg_dice:.4f}, Acc={acc:.4f}")

        # Save best checkpoint
        if avg_dice > best_val_dice:
            best_val_dice = avg_dice
            torch.save(model.state_dict(), f"checkpoints/{model_name}_best.pth")

    total_time = time.time() - start_time
    return history, best_val_dice, acc, total_time

# =========================
# EVALUATION FUNCTION
# =========================
def evaluate_model(model, loader):
    model.eval()
    dice_scores, iou_scores, y_true, y_pred = [], [], [], []
    with torch.no_grad():
        for imgs, masks in loader:
            imgs, masks = imgs.to(CONFIG["device"]), masks.to(CONFIG["device"])
            outputs = model(imgs)
            if isinstance(outputs, dict):
                outputs = outputs["out"]
            preds = (torch.sigmoid(outputs) > 0.5).float()

            for i in range(len(preds)):
                dice_scores.append(dice_score(preds[i], masks[i]).item())
                iou_scores.append(iou_score(preds[i], masks[i]).item())
                gt_cls = int(masks[i].sum() > 0)
                pr_cls = int(preds[i].sum() > 0)
                y_true.append(gt_cls)
                y_pred.append(pr_cls)

    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    return np.mean(dice_scores), np.mean(iou_scores), acc, f1

# =========================
# MAIN PIPELINE
# =========================
def main():
    image_files = sorted(glob.glob(os.path.join(CONFIG["images_dir"], "*.png")))
    mask_files = sorted(glob.glob(os.path.join(CONFIG["masks_dir"], "*.png")))
    assert len(image_files) == len(mask_files)

    train_imgs, val_imgs, train_masks, val_masks = train_test_split(
        image_files, mask_files, test_size=CONFIG["val_split"], random_state=42
    )

    transform = transforms.Compose([transforms.ToTensor()])
    train_dataset = SIIMDataset(train_imgs, train_masks, transform)
    val_dataset   = SIIMDataset(val_imgs, val_masks, transform)

    train_loader = DataLoader(train_dataset, batch_size=CONFIG["batch_size"], shuffle=True)
    val_loader   = DataLoader(val_dataset, batch_size=CONFIG["batch_size"], shuffle=False)

    results = []

    models_to_train = []
    if CONFIG["train_unet"]: models_to_train.append(("U-Net", smp.Unet))
    if CONFIG["train_unetpp"]: models_to_train.append(("U-Net++", smp.UnetPlusPlus))
    if CONFIG["train_nnunet"]: models_to_train.append(("nnU-Net", smp.MAnet))

    for name, ModelClass in models_to_train:
        print(f"\nTraining {name}...")
        model = ModelClass(encoder_name="resnet34", encoder_weights="imagenet", in_channels=3, classes=1).to(CONFIG["device"])
        history, _, _, ttime = train_model(model, train_loader, val_loader, name)
        params = count_parameters(model)/1e6
        size = model_size_mb(model)
        dice_val, iou_val, acc_val, f1_val = evaluate_model(model, val_loader)
        results.append((name, "ResNet34", ModelClass.__name__, params, size, dice_val, iou_val, acc_val, f1_val, ttime))

        plt.plot(history["train_loss"], label="Train Loss")
        plt.plot(history["val_loss"], label="Val Loss")
        plt.title(f"{name} Training Curve")
        plt.legend()
        plt.show()

    # ================= REPORT =================
    print("\n\n================= Final Comparison Report =================")
    print("Model     | Encoder   | Decoder    | Params(M) | Size(MB) | DSC    | IoU    | Acc    | F1")
    print("------------------------------------------------------------------------------------------")
    for r in results:
        print(f"{r[0]:9}| {r[1]:9}| {r[2]:10}| {r[3]:9.2f}| {r[4]:8.2f}| {r[5]:6.4f}| {r[6]:6.4f}| {r[7]:6.4f}| {r[8]:6.4f}")

    # ================= POSITIVE SAMPLE COMPARISON =================
    print("\nGenerating combined comparison figures for positive samples...")
    positive_indices = []
    with torch.no_grad():
        for i, (img, mask) in enumerate(val_dataset):
            if mask.sum() > 0:
                positive_indices.append(i)
            if len(positive_indices) >= 10:
                break

    fig_count = 1
    for start_idx in range(0, len(positive_indices), 5):
        fig, axes = plt.subplots(5, len(models_to_train)+2, figsize=(15, 15))
        for row, idx in enumerate(positive_indices[start_idx:start_idx+5]):
            img, mask = val_dataset[idx]
            img_disp = img.permute(1,2,0).cpu().numpy()

            axes[row, 0].imshow(img_disp); axes[row, 0].set_title("Image"); axes[row,0].axis("off")
            axes[row, 1].imshow(mask[0].cpu(), cmap="gray"); axes[row, 1].set_title("GT"); axes[row,1].axis("off")

            col = 2
            for name, ModelClass in models_to_train:
                model = ModelClass(encoder_name="resnet34", encoder_weights="imagenet", in_channels=3, classes=1).to(CONFIG["device"])
                model.load_state_dict(torch.load(f"checkpoints/{name}_best.pth"))
                model.eval()
                with torch.no_grad():
                    pred = (torch.sigmoid(model(img.unsqueeze(0).to(CONFIG["device"])))[0] > 0.5).float()
                axes[row, col].imshow(pred[0].cpu(), cmap="gray")
                axes[row, col].set_title(f"{name} Pred")
                axes[row, col].axis("off")
                col += 1
        plt.tight_layout()
        plt.savefig(f"combined_comp_{fig_count}.png")
        fig_count += 1
        plt.close(fig)

if __name__ == "__main__":
    main()
