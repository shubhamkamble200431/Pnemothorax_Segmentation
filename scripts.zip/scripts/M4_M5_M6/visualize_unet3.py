# overlay_predictions_comparison_debug.py
import os
import glob
import sys
import torch
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import segmentation_models_pytorch as smp
import torch.nn as nn
import csv
from tqdm import tqdm

print("=" * 80)
print("STARTING OVERLAY PREDICTIONS COMPARISON SCRIPT")
print("=" * 80)

# ---------- CONFIG ----------
DATA_DIR = "dataset"
IMGS_DIR = os.path.join(DATA_DIR, "png_images")
MASKS_DIR = os.path.join(DATA_DIR, "png_masks")
IMG_SIZE = 256
BATCH = 8
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

OUT_DIR = "overlay_outputs"
os.makedirs(OUT_DIR, exist_ok=True)

PRINT_PER_IMAGE_CSV = True
PER_IMAGE_CSV = os.path.join(OUT_DIR, "per_image_metrics.csv")
SUMMARY_CSV = os.path.join(OUT_DIR, "evaluation_summary.csv")

print(f"\n[CONFIG]")
print(f"  Device: {DEVICE}")
print(f"  Image directory: {IMGS_DIR}")
print(f"  Mask directory: {MASKS_DIR}")
print(f"  Image size (model input & plotting): {IMG_SIZE}")
print(f"  Batch size: {BATCH}")
print(f"  Output directory: {OUT_DIR}")

# Paths to your trained checkpoints (update these to your actual files)
CKPT_UNET = "checkpoints/U-Net_best.pth"
CKPT_UNETPP = "checkpoints/U-Net++_best.pth"
CKPT_MANET = "checkpoints/nnU-Net_best.pth"

# Model list (name, constructor lambda, checkpoint)
MODEL_CONFIGS = [
    ("U-Net", lambda: smp.Unet(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=1), CKPT_UNET),
    ("U-Net++", lambda: smp.UnetPlusPlus(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=1), CKPT_UNETPP),
    ("nnU-Net", lambda: smp.MAnet(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=1), CKPT_MANET),
]

# ---------- DATASET ----------
class SIIMDataset(Dataset):
    def __init__(self, img_files, mask_files, img_size=IMG_SIZE, transform=None):
        assert len(img_files) == len(mask_files)
        self.img_files = img_files
        self.mask_files = mask_files
        self.img_size = img_size
        # default transform: resize + to tensor (keeps values 0..1)
        self.transform = transform or transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor()
        ])

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        img_path = self.img_files[idx]
        mask_path = self.mask_files[idx]

        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")

        # apply resizing for both (keeps consistent shapes)
        img_resized = img.resize((self.img_size, self.img_size))
        mask_resized = mask.resize((self.img_size, self.img_size))

        img_t = self.transform(img_resized)  # C,H,W with values in [0,1]
        mask_np = (np.array(mask_resized).astype(np.float32) / 255.0)
        mask_bin = (mask_np > 0.5).astype(np.float32)
        mask_t = torch.from_numpy(mask_bin).unsqueeze(0).float()  # 1,H,W

        # for plotting: HxWx3 with values in 0..1
        img_for_plot = np.array(img_resized).astype(np.float32) / 255.0

        return img_t, mask_t, img_for_plot, img_path

# ---------- METRICS ----------
def dice_score_tensor(pred, target, smooth=1e-6):
    pred = pred.view(-1)
    target = target.view(-1)
    inter = (pred * target).sum()
    return (2. * inter + smooth) / (pred.sum() + target.sum() + smooth)

def dice_numpy(pred_np, target_np, smooth=1e-6):
    p = pred_np.flatten().astype(np.float32)
    t = target_np.flatten().astype(np.float32)
    inter = (p * t).sum()
    return (2. * inter + smooth) / (p.sum() + t.sum() + smooth)

# ---------- HELPERS ----------
def load_model_instance(ctor_fn, ckpt_path, device=DEVICE):
    print(f"    Loading model from: {ckpt_path}")
    model = ctor_fn().to(device)
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")

    state = torch.load(ckpt_path, map_location=device)

    # If wrapped as {'state_dict': ...}
    if isinstance(state, dict) and "state_dict" in state and not any(k.startswith("module.") for k in state.keys()):
        state = state["state_dict"]

    new_state = {}
    if isinstance(state, dict):
        for k, v in state.items():
            nk = k.replace("module.", "")
            new_state[nk] = v
        model.load_state_dict(new_state, strict=False)
    else:
        model.load_state_dict(state)

    model.eval()
    print(f"    Model loaded successfully")
    return model

def overlay_image_with_mask(img, mask, color=(0,0,1), alpha=0.5):
    """
    img: HxWx3 in 0..1
    mask: HxW binary {0,1}
    color: RGB tuple in 0..1
    """
    img = img.copy()
    colored_mask = np.stack([mask*color[0], mask*color[1], mask*color[2]], axis=-1)
    out = img * (1 - alpha * mask[..., None]) + colored_mask * (alpha * mask[..., None])
    out = np.clip(out, 0, 1)
    return out

# ---------- COMPUTE DICE PER IMAGE PER MODEL ----------
def compute_dice_per_image(model, dataset, device=DEVICE, batch_size=8):
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    dice_list = []
    file_order = []
    preds_all = {}
    probs_all = {}

    total_batches = len(loader)
    print(f"    Processing {total_batches} batches...")

    with torch.no_grad():
        for batch_idx, (imgs, masks, imgs_for_plot, file_paths) in enumerate(loader):
            if batch_idx % 10 == 0:
                print(f"      Batch {batch_idx+1}/{total_batches}")
            imgs = imgs.to(device)
            masks = masks.to(device)

            outputs = model(imgs)
            # handle dict outputs from some models
            if isinstance(outputs, dict):
                for k in ("out", "logits"):
                    if k in outputs:
                        outputs = outputs[k]
                        break
                if isinstance(outputs, dict):
                    outputs = list(outputs.values())[0]

            probs = torch.sigmoid(outputs)  # B,1,H,W
            preds = (probs > 0.5).float()

            for i in range(preds.shape[0]):
                p = preds[i,0].cpu().numpy().astype(np.uint8)       # HxW
                prob = probs[i,0].cpu().numpy().astype(np.float32) # HxW
                m = masks[i,0].cpu().numpy().astype(np.uint8)      # HxW (resized)
                fp = file_paths[i]

                # compute dice using the resized mask from dataset (consistent shapes)
                d = float(dice_numpy(p, m))
                dice_list.append(d)
                file_order.append(fp)
                preds_all[fp] = p
                probs_all[fp] = prob

    print(f"    Completed processing all batches")
    return file_order, dice_list, preds_all, probs_all

# ---------- SELECT INDICES ----------
def pick_samples_for_ranges(file_list, dice_list, dataset_mask_map):
    """
    dataset_mask_map: dict mapping fp -> np.array mask (HxW)
    returns indices best, median, worst among images that have positive masks.
    """
    positive_items = [(i, d) for i, d in enumerate(dice_list) if dataset_mask_map[file_list[i]].sum() > 0]

    if len(positive_items) == 0:
        # fallback to all images if none positive
        sorted_all = sorted(list(enumerate(dice_list)), key=lambda x: x[1], reverse=True)
        best = sorted_all[0][0]
        worst = sorted_all[-1][0]
        med = sorted_all[len(sorted_all)//2][0]
        return best, med, worst

    positive_items = sorted(positive_items, key=lambda x: x[1], reverse=True)
    best_idx = positive_items[0][0]
    worst_idx = positive_items[-1][0]
    med_idx = positive_items[len(positive_items) // 2][0]

    print(f"    Best Dice: {dice_list[best_idx]:.4f}, Med: {dice_list[med_idx]:.4f}, Worst: {dice_list[worst_idx]:.4f}")
    return best_idx, med_idx, worst_idx

# ---------- PLOTTING ----------
def make_three_range_plots(model_results, dataset_map, out_dir=OUT_DIR):
    print(f"\n[GENERATING COMPARISON PLOTS]")

    picks = {}
    for mr in model_results:
        print(f"  Selecting samples for {mr['name']}...")
        flist = mr["file_list"]
        dlist = mr["dice_list"]
        mask_map = {p: dataset_map[p][0] for p in flist}
        b, m, w = pick_samples_for_ranges(flist, dlist, mask_map)
        picks[mr["name"]] = {"best": flist[b], "med": flist[m], "worst": flist[w]}

    ranges = [("best", "High (Best)"), ("med", "Medium (Median)"), ("worst", "Poor (Worst)")]
    color_gt = (0.0, 0.0, 1.0)
    color_pred = (1.0, 1.0, 0.0)
    color_error = (1.0, 0.0, 0.0)

    for rkey, rtitle in ranges:
        print(f"  Creating plot for range: {rtitle}")
        n_models = len(model_results)
        fig, axes = plt.subplots(3, n_models, figsize=(4 * n_models, 12))
        if n_models == 1:
            axes = np.expand_dims(axes, 1)

        for col, mr in enumerate(model_results):
            model_name = mr["name"]
            selected_file = picks[model_name][rkey]
            mask_np, img_for_plot = dataset_map[selected_file]
            pred_np = mr["preds_map"][selected_file]
            err_np = ((pred_np.astype(np.uint8) ^ mask_np.astype(np.uint8)) > 0).astype(np.float32)

            # Row 0: GT
            ax = axes[0, col] if axes.ndim==2 else axes[0]
            gt_overlay = overlay_image_with_mask(img_for_plot, mask_np, color=color_gt, alpha=0.6)
            dice_val = mr['dice_list'][mr['file_list'].index(selected_file)]
            ax.imshow(gt_overlay)
            ax.set_title(f"{model_name}\nGT overlay\nDice={dice_val:.4f}")
            ax.axis("off")

            # Row 1: Pred
            ax = axes[1, col] if axes.ndim==2 else axes[1]
            pred_overlay = overlay_image_with_mask(img_for_plot, pred_np, color=color_pred, alpha=0.6)
            ax.imshow(pred_overlay)
            ax.set_title("Pred overlay")
            ax.axis("off")

            # Row 2: Error
            ax = axes[2, col] if axes.ndim==2 else axes[2]
            err_overlay = overlay_image_with_mask(img_for_plot, err_np, color=color_error, alpha=0.7)
            ax.imshow(err_overlay)
            ax.set_title("Error (XOR)")
            ax.axis("off")

        fig.suptitle(f"Range: {rtitle}", fontsize=18)
        plt.tight_layout(rect=[0,0,1,0.96])
        out_path = os.path.join(out_dir, f"comparison_{rkey}.png")
        plt.savefig(out_path, dpi=200, bbox_inches='tight')
        print(f"    ✓ Saved: {out_path}")
        plt.close(fig)

# ---------- SUMMARY CALC ----------
def evaluate_case_level_and_seg_metrics(model_results, dataset_map):
    """
    model_results: list of dicts with keys 'name','file_list','dice_list','preds_map','probs_map'
    dataset_map: mapping fp -> (mask_np, img_for_plot)
    returns summaries dict per model
    """
    summaries = {}
    per_image_rows = []  # for CSV

    for mr in model_results:
        name = mr["name"]
        fl = mr["file_list"]
        dice_vals = []
        iou_vals = []
        pixel_prec = []
        pixel_rec = []
        pixel_f1 = []
        case_gt = []
        case_pred = []
        dice_losses = []
        dice_before_list = []

        for fp in fl:
            gt_mask = dataset_map[fp][0].astype(np.uint8)    # HxW (resized by dataset)
            soft = mr["probs_map"][fp].astype(np.float32)    # HxW
            pred_bin = mr["preds_map"][fp].astype(np.uint8)  # HxW

            # dice before (soft->0.5)
            pred_before = (soft >= 0.5).astype(np.uint8)
            dice_before = dice_numpy(pred_before, gt_mask)
            dice_before_list.append(dice_before)

            # pixel-level after threshold (we used 0.5)
            dice_v = dice_numpy(pred_bin, gt_mask)
            dice_vals.append(dice_v)

            inter = np.logical_and(pred_bin, gt_mask).sum()
            union = np.logical_or(pred_bin, gt_mask).sum()
            iou_vals.append(float(inter) / float(union) if union>0 else 0.0)

            tp = inter
            fp_pix = (pred_bin & (~gt_mask)).sum()
            fn_pix = ((~pred_bin) & gt_mask).sum()
            prec = tp / (tp + fp_pix) if (tp + fp_pix) > 0 else 0.0
            rec = tp / (tp + fn_pix) if (tp + fn_pix) > 0 else 0.0
            f1v = (2*prec*rec) / (prec+rec) if (prec+rec) > 0 else 0.0
            pixel_prec.append(prec)
            pixel_rec.append(rec)
            pixel_f1.append(f1v)

            gt_case = int(gt_mask.sum() > 0)
            pred_case = int(pred_bin.sum() > 0)
            case_gt.append(gt_case)
            case_pred.append(pred_case)

            dl = dice_loss_from_soft(soft, gt_mask)
            dice_losses.append(dl)

            # store per-image row
            per_image_rows.append({
                "model": name,
                "file": fp,
                "dice_pixel": float(dice_v),
                "iou_pixel": float(iou_vals[-1]),
                "pix_prec": float(prec),
                "pix_rec": float(rec),
                "pix_f1": float(f1v),
                "dice_before": float(dice_before),
                "dice_loss_soft": float(dl),
                "case_gt": gt_case,
                "case_pred": pred_case
            })

        # case-level confusion & metrics
        if len(set(case_gt)) > 1:
            tn, fp_c, fn_c, tp_c = confusion_matrix(case_gt, case_pred, labels=[0,1]).ravel()
        else:
            tn = fp_c = fn_c = tp_c = 0

        acc = accuracy_score(case_gt, case_pred)
        prec_case = precision_score(case_gt, case_pred, zero_division=0)
        rec_case = recall_score(case_gt, case_pred, zero_division=0)
        f1_case = f1_score(case_gt, case_pred, zero_division=0)
        spec_case = tn / (tn + fp_c) if (tn + fp_c) > 0 else 0.0

        summaries[name] = {
            "mean_pixel_dice": float(np.mean(dice_vals)) if len(dice_vals)>0 else 0.0,
            "mean_pixel_iou": float(np.mean(iou_vals)) if len(iou_vals)>0 else 0.0,
            "mean_pixel_precision": float(np.mean(pixel_prec)) if len(pixel_prec)>0 else 0.0,
            "mean_pixel_recall": float(np.mean(pixel_rec)) if len(pixel_rec)>0 else 0.0,
            "mean_pixel_f1": float(np.mean(pixel_f1)) if len(pixel_f1)>0 else 0.0,
            "case_confusion": (int(tn), int(fp_c), int(fn_c), int(tp_c)),
            "case_accuracy": float(acc),
            "case_precision": float(prec_case),
            "case_recall": float(rec_case),
            "case_f1": float(f1_case),
            "case_specificity": float(spec_case),
            "mean_dice_loss": float(np.mean(dice_losses)) if len(dice_losses)>0 else 0.0,
            "mean_dice_before": float(np.mean(dice_before_list)) if len(dice_before_list)>0 else 0.0,
            "num_images": len(fl)
        }

    return summaries, per_image_rows

# helper metrics functions used above
from scipy import ndimage as ndi
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

def dice_loss_from_soft(soft_pred, target_bin, smooth=1e-6):
    p = soft_pred.flatten().astype(np.float32)
    g = target_bin.flatten().astype(np.float32)
    inter = (p * g).sum()
    dice = (2. * inter + smooth) / (p.sum() + g.sum() + smooth)
    return 1.0 - dice

# ---------- MAIN ----------
def main():
    try:
        # Check data directories
        print(f"\n[CHECKING DATA DIRECTORIES]")
        if not os.path.exists(IMGS_DIR):
            print(f"  ✗ ERROR: Image directory not found: {IMGS_DIR}")
            sys.exit(1)
        print(f"  ✓ Image directory exists: {IMGS_DIR}")

        if not os.path.exists(MASKS_DIR):
            print(f"  ✗ ERROR: Mask directory not found: {MASKS_DIR}")
            sys.exit(1)
        print(f"  ✓ Mask directory exists: {MASKS_DIR}")

        # Gather files
        print(f"\n[LOADING DATASET]")
        image_files = sorted(glob.glob(os.path.join(IMGS_DIR, "*.png")))
        mask_files = sorted(glob.glob(os.path.join(MASKS_DIR, "*.png")))

        print(f"  Found {len(image_files)} images")
        print(f"  Found {len(mask_files)} masks")

        if len(image_files) == 0 or len(mask_files) == 0:
            print(f"  ✗ ERROR: images or masks missing (counts: images={len(image_files)}, masks={len(mask_files)})")
            sys.exit(1)

        if len(image_files) != len(mask_files):
            print(f"  ✗ ERROR: Number of images and masks must match (images={len(image_files)}, masks={len(mask_files)})")
            sys.exit(1)

        ds = SIIMDataset(image_files, mask_files, img_size=IMG_SIZE)

        # Build dataset map (resized masks + plotting images)
        print(f"\n[BUILDING DATASET MAP]")
        dataset_map = {}
        for i in range(len(ds)):
            _, mask_t, img_for_plot, fp = ds[i]
            dataset_map[fp] = (mask_t.squeeze(0).numpy().astype(np.uint8), img_for_plot)
        print(f"  ✓ Built map for {len(dataset_map)} samples")

        # Check checkpoints
        print(f"\n[CHECKING MODEL CHECKPOINTS]")
        for name, _, ckpt in MODEL_CONFIGS:
            if os.path.exists(ckpt):
                print(f"  ✓ {name}: {ckpt}")
            else:
                print(f"  ✗ {name}: NOT FOUND - {ckpt}")

        # Load models and compute predictions
        print(f"\n[LOADING & RUNNING MODELS]")
        model_results = []
        for name, ctor_fn, ckpt in MODEL_CONFIGS:
            if not os.path.exists(ckpt):
                print(f"  ✗ Skipping {name} (checkpoint not found)")
                continue

            print(f"\n  Processing {name} ...")
            try:
                model = load_model_instance(ctor_fn, ckpt, device=DEVICE)
            except Exception as e:
                print(f"    ✗ Error loading model {name}: {e}")
                continue

            try:
                file_list, dice_list, preds_map, probs_map = compute_dice_per_image(model, ds, device=DEVICE, batch_size=BATCH)
            except Exception as e:
                print(f"    ✗ Error during inference for {name}: {e}")
                continue

            avg_dice = float(np.mean(dice_list)) if len(dice_list)>0 else 0.0
            print(f"    ✓ Completed {name}. Average Dice: {avg_dice:.4f}")

            model_results.append({
                "name": name,
                "file_list": file_list,
                "dice_list": dice_list,
                "preds_map": preds_map,
                "probs_map": probs_map,
                "model": model
            })

        if len(model_results) == 0:
            print(f"\n✗ ERROR: No models loaded successfully. Check checkpoint paths.")
            sys.exit(1)

        print(f"\n  ✓ Successfully loaded {len(model_results)} model(s)")

        # Generate comparison plots
        make_three_range_plots(model_results, dataset_map, out_dir=OUT_DIR)

        # Compute summary metrics and save CSVs
        print(f"\n[COMPUTING SUMMARY METRICS]")
        summaries, per_image_rows = evaluate_case_level_and_seg_metrics(model_results, dataset_map)

        print("\n\n==== Evaluation Summary ====")
        # Print summaries and write summary CSV
        with open(SUMMARY_CSV, "w", newline="") as fsum:
            writer = csv.writer(fsum)
            writer.writerow(["Model", "NumImages", "MeanPixelDice", "MeanIoU", "PixelPrec", "PixelRec", "PixelF1",
                             "CaseAcc", "CasePrec", "CaseRec", "CaseF1", "CaseSpec", "TN", "FP", "FN", "TP", "MeanDiceLoss", "MeanDiceBefore"])
            for name, s in summaries.items():
                tn, fp_c, fn_c, tp_c = s["case_confusion"]
                writer.writerow([name,
                                 s["num_images"],
                                 f"{s['mean_pixel_dice']:.6f}",
                                 f"{s['mean_pixel_iou']:.6f}",
                                 f"{s['mean_pixel_precision']:.6f}",
                                 f"{s['mean_pixel_recall']:.6f}",
                                 f"{s['mean_pixel_f1']:.6f}",
                                 f"{s['case_accuracy']:.6f}",
                                 f"{s['case_precision']:.6f}",
                                 f"{s['case_recall']:.6f}",
                                 f"{s['case_f1']:.6f}",
                                 f"{s['case_specificity']:.6f}",
                                 tn, fp_c, fn_c, tp_c,
                                 f"{s['mean_dice_loss']:.6f}",
                                 f"{s['mean_dice_before']:.6f}"])
                # print summary
                print(f"\nModel: {name}")
                print(f"  Num images: {s['num_images']}")
                print(f"  Mean Pixel Dice: {s['mean_pixel_dice']:.4f}, Mean IoU: {s['mean_pixel_iou']:.4f}")
                print(f"  Pixel Prec/Rec/F1: {s['mean_pixel_precision']:.4f}/{s['mean_pixel_recall']:.4f}/{s['mean_pixel_f1']:.4f}")
                tn, fp_c, fn_c, tp_c = s["case_confusion"]
                print(f"  Case Confusion (TN,FP,FN,TP): {tn},{fp_c},{fn_c},{tp_c}")
                print(f"  Case Acc/Prec/Rec/F1/Spec: {s['case_accuracy']:.4f}/{s['case_precision']:.4f}/{s['case_recall']:.4f}/{s['case_f1']:.4f}/{s['case_specificity']:.4f}")
                print(f"  Mean Dice Loss (soft): {s['mean_dice_loss']:.6f}")
        print(f"\nSaved summary CSV: {SUMMARY_CSV}")

        # Save per-image CSV
        if PRINT_PER_IMAGE_CSV:
            fieldnames = ["model","file","dice_pixel","iou_pixel","pix_prec","pix_rec","pix_f1","dice_before","dice_loss_soft","case_gt","case_pred"]
            with open(PER_IMAGE_CSV, "w", newline="") as fp:
                writer = csv.DictWriter(fp, fieldnames=fieldnames)
                writer.writeheader()
                for row in per_image_rows:
                    writer.writerow(row)
            print(f"Saved per-image metrics CSV: {PER_IMAGE_CSV}")

        print("\n" + "=" * 80)
        print("✓ COMPLETED SUCCESSFULLY")
        print(f"  Check output files in: {OUT_DIR}")
        print("=" * 80)

    except Exception as e:
        print(f"\n✗ FATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
