# overlay_predictions_comparison_debug.py
import os
import glob
import sys
import torch
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import segmentation_models_pytorch as smp
import torch.nn as nn

print("=" * 60)
print("STARTING OVERLAY PREDICTIONS COMPARISON SCRIPT")
print("=" * 60)

# ---------- CONFIG ----------
DATA_DIR = "dataset"
IMGS_DIR = os.path.join(DATA_DIR, "png_images")
MASKS_DIR = os.path.join(DATA_DIR, "png_masks")
IMG_SIZE = 256
BATCH = 8
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

print(f"\n[CONFIG]")
print(f"  Device: {DEVICE}")
print(f"  Image directory: {IMGS_DIR}")
print(f"  Mask directory: {MASKS_DIR}")
print(f"  Image size: {IMG_SIZE}")
print(f"  Batch size: {BATCH}")

# Paths to your trained checkpoints
CKPT_UNET = "checkpoints/U-Net_best.pth"
CKPT_UNETPP = "checkpoints/U-Net++_best.pth"
CKPT_MANET = "checkpoints/nnU-Net_best.pth"

# Model list
MODEL_CONFIGS = [
    ("U-Net", lambda: smp.Unet(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=1), CKPT_UNET),
    ("U-Net++", lambda: smp.UnetPlusPlus(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=1), CKPT_UNETPP),
    ("nnU-Net", lambda: smp.MAnet(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=1), CKPT_MANET),
]

OUT_DIR = "overlay_outputs"
os.makedirs(OUT_DIR, exist_ok=True)
print(f"  Output directory: {OUT_DIR}")

# ---------- DATASET ----------
class SIIMDataset(Dataset):
    def __init__(self, img_files, mask_files, img_size=IMG_SIZE, transform=None):
        assert len(img_files) == len(mask_files)
        self.img_files = img_files
        self.mask_files = mask_files
        self.img_size = img_size
        self.transform = transform or transforms.Compose([transforms.Resize((img_size, img_size)), transforms.ToTensor()])

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        img = Image.open(self.img_files[idx]).convert("RGB")
        mask = Image.open(self.mask_files[idx]).convert("L")
        img = img.resize((self.img_size, self.img_size))
        mask = mask.resize((self.img_size, self.img_size))
        img_t = self.transform(img)
        mask_np = (np.array(mask).astype(np.float32) / 255.0)
        mask_bin = (mask_np > 0.5).astype(np.float32)
        mask_t = torch.from_numpy(mask_bin).unsqueeze(0).float()
        img_for_plot = np.array(img).astype(np.float32) / 255.0
        return img_t, mask_t, img_for_plot, self.img_files[idx]

# ---------- METRICS ----------
def dice_score_tensor(pred, target, smooth=1e-6):
    pred = pred.view(-1)
    target = target.view(-1)
    inter = (pred * target).sum()
    return (2. * inter + smooth) / (pred.sum() + target.sum() + smooth)

# ---------- HELPERS ----------
def load_model_instance(ctor_fn, ckpt_path, device=DEVICE):
    print(f"    Loading model from: {ckpt_path}")
    model = ctor_fn().to(device)
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
    
    state = torch.load(ckpt_path, map_location=device)
    
    if isinstance(state, dict) and "state_dict" in state and not any(k.startswith("module.") for k in state.keys()):
        state = state["state_dict"]
    
    new_state = {}
    if isinstance(state, dict):
        for k, v in state.items():
            nk = k.replace("module.", "")
            new_state[nk] = v
        model.load_state_dict(new_state, strict=False)
    else:
        model.load_state_dict(state)
    
    model.eval()
    print(f"    Model loaded successfully")
    return model

def overlay_image_with_mask(img, mask, color=(0,0,1), alpha=0.5):
    img = img.copy()
    colored_mask = np.stack([mask*color[0], mask*color[1], mask*color[2]], axis=-1)
    out = img * (1 - alpha*mask[..., None]) + colored_mask * (alpha*mask[..., None])
    out = np.clip(out, 0, 1)
    return out

# ---------- COMPUTE DICE PER IMAGE PER MODEL ----------
def compute_dice_per_image(model, dataset, device=DEVICE, batch_size=8):
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    dice_list = []
    file_order = []
    preds_all = {}
    
    total_batches = len(loader)
    print(f"    Processing {total_batches} batches...")
    
    with torch.no_grad():
        for batch_idx, (imgs, masks, imgs_for_plot, file_paths) in enumerate(loader):
            if batch_idx % 10 == 0:
                print(f"      Batch {batch_idx+1}/{total_batches}")
            
            imgs = imgs.to(device)
            masks = masks.to(device)
            outputs = model(imgs)
            
            if isinstance(outputs, dict):
                for k in ("out", "logits"):
                    if k in outputs:
                        outputs = outputs[k]
                        break
                if isinstance(outputs, dict):
                    outputs = list(outputs.values())[0]
            
            probs = torch.sigmoid(outputs)
            preds = (probs > 0.5).float()
            
            for i in range(preds.shape[0]):
                p = preds[i,0].cpu().numpy().astype(np.uint8)
                m = masks[i,0].cpu().numpy().astype(np.uint8)
                d = dice_score_tensor(torch.from_numpy(p), torch.from_numpy(m)).item()
                fp = file_paths[i]
                dice_list.append(d)
                file_order.append(fp)
                preds_all[fp] = p
    
    print(f"    Completed processing all batches")
    return file_order, dice_list, preds_all

# ---------- SELECT INDICES ----------
def pick_samples_for_ranges(file_list, dice_list, dataset_mask_map, n_candidates=3):
    positive_items = [(i, d) for i, d in enumerate(dice_list) if dataset_mask_map[file_list[i]].sum() > 0]
    
    if len(positive_items) == 0:
        raise RuntimeError("No positive-mask images in dataset.")
    
    print(f"    Found {len(positive_items)} images with positive masks")
    positive_items = sorted(positive_items, key=lambda x: x[1], reverse=True)
    
    best_idx = positive_items[0][0]
    worst_idx = positive_items[-1][0]
    mid_pos = len(positive_items) // 2
    med_idx = positive_items[mid_pos][0]
    
    print(f"    Best Dice: {dice_list[best_idx]:.4f}, Med: {dice_list[med_idx]:.4f}, Worst: {dice_list[worst_idx]:.4f}")
    
    return best_idx, med_idx, worst_idx

# ---------- PLOTTING ----------
def make_three_range_plots(model_results, dataset_map, out_dir=OUT_DIR):
    print(f"\n[GENERATING COMPARISON PLOTS]")
    
    picks = {}
    for mr in model_results:
        print(f"  Selecting samples for {mr['name']}...")
        flist = mr["file_list"]
        dlist = mr["dice_list"]
        mask_map = {p: dataset_map[p][0] for p in flist}
        b, m, w = pick_samples_for_ranges(flist, dlist, mask_map)
        picks[mr["name"]] = {"best": flist[b], "med": flist[m], "worst": flist[w]}
    
    ranges = [("best", "High (Best)"), ("med", "Medium (Median)"), ("worst", "Poor (Worst)")]
    color_gt = (0.0, 0.0, 1.0)
    color_pred = (1.0, 1.0, 0.0)
    color_error = (1.0, 0.0, 0.0)
    
    for rkey, rtitle in ranges:
        print(f"  Creating plot for range: {rtitle}")
        fig, axes = plt.subplots(3, len(model_results), figsize=(4 * len(model_results), 12))
        if len(model_results) == 1:
            axes = np.expand_dims(axes, 1)
        
        for col, mr in enumerate(model_results):
            model_name = mr["name"]
            selected_file = picks[model_name][rkey]
            mask_np, img_for_plot = dataset_map[selected_file]
            pred_np = mr["preds_map"][selected_file]
            err_np = ((pred_np.astype(np.uint8) ^ mask_np.astype(np.uint8)) > 0).astype(np.float32)
            
            # Row 0: GT
            ax = axes[0, col] if axes.ndim==2 else axes[0]
            gt_overlay = overlay_image_with_mask(img_for_plot, mask_np, color=color_gt, alpha=0.6)
            ax.imshow(gt_overlay)
            ax.set_title(f"{model_name}\nGT overlay\nDice={mr['dice_list'][mr['file_list'].index(selected_file)]:.4f}")
            ax.axis("off")
            
            # Row 1: Pred
            ax = axes[1, col] if axes.ndim==2 else axes[1]
            pred_overlay = overlay_image_with_mask(img_for_plot, pred_np, color=color_pred, alpha=0.6)
            ax.imshow(pred_overlay)
            ax.set_title("Pred overlay")
            ax.axis("off")
            
            # Row 2: Error
            ax = axes[2, col] if axes.ndim==2 else axes[2]
            err_overlay = overlay_image_with_mask(img_for_plot, err_np, color=color_error, alpha=0.7)
            ax.imshow(err_overlay)
            ax.set_title("Error (XOR)")
            ax.axis("off")
        
        fig.suptitle(f"Range: {rtitle}", fontsize=18)
        plt.tight_layout(rect=[0,0,1,0.96])
        out_path = os.path.join(out_dir, f"comparison_{rkey}.png")
        plt.savefig(out_path, dpi=200)
        print(f"    ✓ Saved: {out_path}")
        plt.close(fig)

# ---------- MAIN ----------
def main():
    try:
        # Check data directories
        print(f"\n[CHECKING DATA DIRECTORIES]")
        if not os.path.exists(IMGS_DIR):
            print(f"  ✗ ERROR: Image directory not found: {IMGS_DIR}")
            sys.exit(1)
        print(f"  ✓ Image directory exists: {IMGS_DIR}")
        
        if not os.path.exists(MASKS_DIR):
            print(f"  ✗ ERROR: Mask directory not found: {MASKS_DIR}")
            sys.exit(1)
        print(f"  ✓ Mask directory exists: {MASKS_DIR}")
        
        # Gather files
        print(f"\n[LOADING DATASET]")
        image_files = sorted(glob.glob(os.path.join(IMGS_DIR, "*.png")))
        mask_files = sorted(glob.glob(os.path.join(MASKS_DIR, "*.png")))
        
        print(f"  Found {len(image_files)} images")
        print(f"  Found {len(mask_files)} masks")
        
        if len(image_files) == 0:
            print(f"  ✗ ERROR: No PNG images found in {IMGS_DIR}")
            sys.exit(1)
        
        if len(mask_files) == 0:
            print(f"  ✗ ERROR: No PNG masks found in {MASKS_DIR}")
            sys.exit(1)
        
        assert len(image_files) == len(mask_files), "Number of images and masks must match"
        print(f"  ✓ Dataset loaded: {len(image_files)} image-mask pairs")
        
        ds = SIIMDataset(image_files, mask_files, img_size=IMG_SIZE)
        
        # Build dataset map
        print(f"\n[BUILDING DATASET MAP]")
        dataset_map = {}
        for i in range(len(ds)):
            _, mask_t, img_for_plot, fp = ds[i]
            dataset_map[fp] = (mask_t.squeeze(0).numpy().astype(np.uint8), img_for_plot)
        print(f"  ✓ Built map for {len(dataset_map)} samples")
        
        # Check checkpoints
        print(f"\n[CHECKING MODEL CHECKPOINTS]")
        for name, _, ckpt in MODEL_CONFIGS:
            if os.path.exists(ckpt):
                print(f"  ✓ {name}: {ckpt}")
            else:
                print(f"  ✗ {name}: NOT FOUND - {ckpt}")
        
        # Load models
        print(f"\n[LOADING MODELS]")
        model_results = []
        for name, ctor_fn, ckpt in MODEL_CONFIGS:
            if not os.path.exists(ckpt):
                print(f"  ✗ Skipping {name} (checkpoint not found)")
                continue
            
            print(f"  Processing {name}...")
            try:
                model = load_model_instance(ctor_fn, ckpt, device=DEVICE)
                print(f"    Computing predictions...")
                file_list, dice_list, preds_map = compute_dice_per_image(model, ds, device=DEVICE, batch_size=BATCH)
                avg_dice = np.mean(dice_list)
                print(f"    ✓ Completed. Average Dice: {avg_dice:.4f}")
                
                model_results.append({
                    "name": name,
                    "file_list": file_list,
                    "dice_list": dice_list,
                    "preds_map": preds_map,
                    "model": model
                })
            except Exception as e:
                print(f"    ✗ Error loading {name}: {e}")
                continue
        
        if len(model_results) == 0:
            print(f"\n✗ ERROR: No models loaded successfully. Check checkpoint paths.")
            sys.exit(1)
        
        print(f"\n  ✓ Successfully loaded {len(model_results)} model(s)")
        
        # Generate plots
        make_three_range_plots(model_results, dataset_map, out_dir=OUT_DIR)
        
        print("\n" + "=" * 60)
        print("✓ COMPLETED SUCCESSFULLY")
        print(f"  Check output files in: {OUT_DIR}")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n✗ FATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()