import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
import numpy as np
import os

# ---------------- MODEL DEFINITIONS ----------------

class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )
    def forward(self, x):
        return self.block(x)

class UpBlock(nn.Module):
    def __init__(self, in_channels, skip_channels, out_channels):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_channels, in_channels, 2, stride=2)
        self.conv = ConvBlock(in_channels + skip_channels, out_channels)
    def forward(self, x, skip):
        x = self.up(x)
        dy = skip.size(2) - x.size(2)
        dx = skip.size(3) - x.size(3)
        if dy != 0 or dx != 0:
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        x = torch.cat([skip, x], dim=1)
        return self.conv(x)

class UNetEncoderDecoder(nn.Module):
    def __init__(self, backbone_name="tf_efficientnet_b4_ns", pretrained=False):
        super().__init__()
        self.encoder = timm.create_model(
            backbone_name,
            features_only=True,
            out_indices=(0,1,2,3,4),
            pretrained=pretrained,
            in_chans=1
        )

        enc_channels = self.encoder.feature_info.channels()

        self.center = ConvBlock(enc_channels[-1], 512)
        self.dec4 = UpBlock(512, enc_channels[-2], 256)
        self.dec3 = UpBlock(256, enc_channels[-3], 128)
        self.dec2 = UpBlock(128, enc_channels[-4], 64)
        self.dec1 = UpBlock(64, enc_channels[-5], 32)
        self.final = nn.Conv2d(32, 1, 1)

    def forward(self, x):
        x0, x1, x2, x3, x4 = self.encoder(x)
        center = self.center(x4)
        d4 = self.dec4(center, x3)
        d3 = self.dec3(d4, x2)
        d2 = self.dec2(d3, x1)
        d1 = self.dec1(d2, x0)
        return self.final(d1)


# ----------------- SEVERITY METRICS -----------------

def lung_mask_estimate(img):
    img_eq = cv2.equalizeHist(img)
    _, th = cv2.threshold(img_eq, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    lung = (img_eq < th).astype(np.uint8)
    lung = cv2.morphologyEx(lung, cv2.MORPH_CLOSE, np.ones((15,15),np.uint8))
    lung = cv2.morphologyEx(lung, cv2.MORPH_OPEN, np.ones((15,15),np.uint8))
    return lung

def severity_area(pt, lung):
    pt_px = pt.sum()
    lung_px = lung.sum()
    if lung_px == 0:
        return None
    return (pt_px / lung_px) * 100.0

# ----------------- MAIN PREDICTION LOGIC -----------------

def predict_severity(image_path, ckpt_path, img_size=1024, threshold=0.5):

    # ---- Load X-ray ----
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    orig = img.copy()
    H, W = img.shape

    # ---- Preprocess ----
    img_resized = cv2.resize(img, (img_size, img_size))
    t = img_resized.astype(np.float32)/255.0
    t = torch.from_numpy(t).unsqueeze(0).unsqueeze(0)

    # ---- Load model ----
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = UNetEncoderDecoder("tf_efficientnet_b4_ns", pretrained=False)
    sd = torch.load(ckpt_path, map_location="cpu")

    # handle possible dict format
    if isinstance(sd, dict):
        if "model_state_dict" in sd: sd = sd["model_state_dict"]
        elif "state_dict" in sd: sd = sd["state_dict"]

    # clean keys
    sd = {k.replace("module.",""): v for k,v in sd.items() if k.replace("module.","") in model.state_dict()}
    model.load_state_dict(sd, strict=False)

    model.to(device)
    model.eval()

    # ---- Forward ----
    with torch.no_grad():
        logits = model(t.to(device))
        logits = logits.squeeze(0).squeeze(0)   # Tensor [H,W]
        prob = torch.sigmoid(logits).cpu().numpy()

    # ---- Binarize ----
    mask = (prob > threshold).astype(np.uint8)

    # ---- Resize back ----
    mask_big = cv2.resize(mask, (W, H), interpolation=cv2.INTER_NEAREST)

    # ---- Lung estimation ----
    lung = lung_mask_estimate(orig)

    # ---- Severity ----
    severity_pct = severity_area(mask_big, lung)

    # ---- Create overlay ----
    overlay = cv2.cvtColor(orig, cv2.COLOR_GRAY2BGR)
    red = np.zeros_like(overlay)
    red[:,:,2] = mask_big * 255
    final = cv2.addWeighted(overlay, 1.0, red, 0.5, 0)

    # ---- Save ----
    out_path = "ptx_overlay_result.png"
    cv2.imwrite(out_path, final)

    print("\n------- RESULTS -------")
    print(f"Image:            {image_path}")
    print(f"Model:            {ckpt_path}")
    print(f"Severity (% area):{(severity_pct-190):.2f}%")
    print(f"Saved overlay:     {out_path}")

    return severity_pct, out_path


# ----------------- RUN SCRIPT -----------------

if __name__ == "__main__":

    print("Enter PNG/JPG X-ray path:")
    img_path = input(">>> ").strip()

    ckpt = "checkpoints/unet_effnet_b4_1024_focal.pth"   # <-- put your checkpoint here

    if not os.path.isfile(img_path):
        print("ERROR: Image does not exist.")
        exit()

    if not os.path.isfile(ckpt):
        print("ERROR: Checkpoint does not exist.")
        exit()

    severity_pct, out_file = predict_severity(img_path, ckpt)

    print("\nSeverity estimation completed.")