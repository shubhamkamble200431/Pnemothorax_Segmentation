#!/usr/bin/env python3
"""
Unified evaluation script — save only 3 overlays per model (best, median, worst)
for label=1 (positive-mask cases).

Usage:
    edit DATA_ROOT and CHECKPOINTS as needed, then run:
        python unified_eval_top3_pos_only.py
"""
import os
import glob
import sys
from pathlib import Path
from typing import List, Tuple, Dict, Optional

import numpy as np
import cv2
from PIL import Image
import matplotlib.pyplot as plt
from tqdm import tqdm
import scipy.ndimage as ndi

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

import timm

# ----------------- CONFIG -----------------
DATA_ROOT = "/media/admin1/DL/shubham/FYP_2.0/final_dataset"  # change if needed
OUT_DIR = "./eval_outputs"
CKPT_DIR = "./checkpoints"
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "overlays"), exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "preds"), exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 8
TTA_KEYS = ["none", "hflip"]
THRESHOLD = 0.5
MIN_COMPONENT_AREA = 100

# Checkpoint paths (edit if yours are different)
CHECKPOINTS = {
    "PTXSegNet_highres": os.path.join(CKPT_DIR, "ptxseg_net_high_lr_best.pth"),
    "UNet_ResNet50_1024_focal": os.path.join(CKPT_DIR, "unet_r50_1024_focal.pth"),
    "UNet_EffNetB4_1024_focal": os.path.join(CKPT_DIR, "unet_effnet_b4_1024_focal.pth"),
}

MODEL_SPECS = {}

# ----------------- UTILITIES & METRICS -----------------
def dice_numpy(pred_np: np.ndarray, target_np: np.ndarray, smooth=1e-6) -> float:
    p = pred_np.flatten().astype(np.float32)
    t = target_np.flatten().astype(np.float32)
    inter = (p * t).sum()
    denom = p.sum() + t.sum()
    if denom == 0:
        return 1.0
    return float((2. * inter + smooth) / (denom + smooth))

def iou_numpy(pred_np: np.ndarray, target_np: np.ndarray) -> float:
    p = pred_np.astype(bool)
    t = target_np.astype(bool)
    inter = np.logical_and(p, t).sum()
    union = np.logical_or(p, t).sum()
    if union == 0:
        return 1.0
    return float(inter / union)

def precision_recall_f1(pred_np: np.ndarray, target_np: np.ndarray) -> Tuple[float,float,float]:
    p = pred_np.astype(bool)
    t = target_np.astype(bool)
    tp = np.logical_and(p, t).sum()
    fp = np.logical_and(p, ~t).sum()
    fn = np.logical_and(~p, t).sum()
    prec = tp / (tp + fp) if (tp+fp)>0 else 0.0
    rec = tp / (tp + fn) if (tp+fn)>0 else 0.0
    f1 = (2*prec*rec)/(prec+rec) if (prec+rec)>0 else 0.0
    return prec, rec, f1

def postprocess_softmask(soft: np.ndarray, threshold: float, min_component_size: int) -> np.ndarray:
    bin_mask = (soft >= threshold).astype(np.uint8)
    bin_mask = ndi.binary_fill_holes(bin_mask).astype(np.uint8)
    if min_component_size > 0:
        labeled, num = ndi.label(bin_mask)
        sizes = ndi.sum(bin_mask, labeled, range(1, num+1))
        cleaned = np.zeros_like(bin_mask)
        for i, s in enumerate(sizes, start=1):
            if s >= min_component_size:
                cleaned[labeled == i] = 1
        bin_mask = cleaned
    if bin_mask.sum() > 0:
        kernel = np.ones((3,3), np.uint8)
        bin_mask = cv2.morphologyEx(bin_mask.astype(np.uint8), cv2.MORPH_CLOSE, kernel)
    return bin_mask.astype(np.uint8)

def overlay_image_with_mask(img: np.ndarray, mask: np.ndarray, color=(1.0, 1.0, 0.0), alpha=0.5):
    img = img.copy()
    colored = np.zeros_like(img)
    colored[..., 0] = color[0]
    colored[..., 1] = color[1]
    colored[..., 2] = color[2]
    out = img * (1 - alpha * mask[..., None]) + colored * (alpha * mask[..., None])
    out = np.clip(out, 0, 1)
    return out

# ----------------- SIIMDataset (grayscale) -----------------
class SIIMDataset(Dataset):
    """
    Returns:
     - img_t : torch.Tensor (1,H,W) single-channel normalized 0..1
     - mask_t: torch.Tensor (1,H,W) binary {0,1}
     - img_for_plot: HxWx3 float32 0..1 (RGB)
     - fp: filepath
    """
    def __init__(self, img_files: List[str], mask_files: List[str], img_size: int = 512):
        assert len(img_files) == len(mask_files)
        self.img_files = img_files
        self.mask_files = mask_files
        self.img_size = img_size

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        img_path = self.img_files[idx]
        mask_path = self.mask_files[idx]

        img = Image.open(img_path).convert("L")
        mask = Image.open(mask_path).convert("L")

        img_resized = img.resize((self.img_size, self.img_size), resample=Image.BILINEAR)
        mask_resized = mask.resize((self.img_size, self.img_size), resample=Image.NEAREST)

        img_np = np.array(img_resized).astype(np.float32) / 255.0
        mask_np = (np.array(mask_resized).astype(np.float32) / 255.0)
        mask_bin = (mask_np > 0.5).astype(np.uint8)

        img_t = torch.from_numpy(img_np).unsqueeze(0).float()           # 1,H,W
        mask_t = torch.from_numpy(mask_bin).unsqueeze(0).float()       # 1,H,W

        img_for_plot = np.stack([img_np, img_np, img_np], axis=-1).astype(np.float32)  # H,W,3 0..1

        return img_t, mask_t, img_for_plot, img_path

# ----------------- PTXSegNet (as provided) -----------------
class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.relu = nn.LeakyReLU(0.2, inplace=True)
    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.relu(self.bn2(self.conv2(x)))
        return x

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.relu = nn.LeakyReLU(0.2, inplace=True)
        self.residual = nn.Sequential()
        if in_channels != out_channels:
            self.residual = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1),
                nn.BatchNorm2d(out_channels)
            )
    def forward(self, x):
        residual = self.residual(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += residual
        out = self.relu(out)
        return out

class AttentionGate(nn.Module):
    def __init__(self, F_g, F_l, F_int):
        super().__init__()
        self.W_g = nn.Sequential(nn.Conv2d(F_g, F_int, 1, padding=0, bias=True), nn.BatchNorm2d(F_int))
        self.W_x = nn.Sequential(nn.Conv2d(F_l, F_int, 1, padding=0, bias=True), nn.BatchNorm2d(F_int))
        self.psi = nn.Sequential(nn.Conv2d(F_int, 1, 1, padding=0, bias=True), nn.BatchNorm2d(1), nn.Sigmoid())
        self.relu = nn.ReLU(inplace=True)
    def forward(self, g, x):
        g1 = self.W_g(g); x1 = self.W_x(x)
        psi = self.relu(g1 + x1); psi = self.psi(psi)
        return x * psi

class PTXSegNet(nn.Module):
    def __init__(self, config: Dict):
        super().__init__()
        self.use_attention = config.get('attention', True)
        self.use_residual = config.get('residual', True)
        self.deep_supervision = config.get('deep_supervision', True)
        channels = config.get('channels', [64,128,256,512,1024])
        BlockType = ResidualBlock if self.use_residual else ConvBlock
        self.enc1 = BlockType(1, channels[0])
        self.enc2 = BlockType(channels[0], channels[1])
        self.enc3 = BlockType(channels[1], channels[2])
        self.enc4 = BlockType(channels[2], channels[3])
        self.pool = nn.MaxPool2d(2)
        self.bottleneck = BlockType(channels[3], channels[4])
        self.up4 = nn.ConvTranspose2d(channels[4], channels[3], 2, stride=2)
        self.dec4 = BlockType(channels[4], channels[3])
        self.up3 = nn.ConvTranspose2d(channels[3], channels[2], 2, stride=2)
        self.dec3 = BlockType(channels[3], channels[2])
        self.up2 = nn.ConvTranspose2d(channels[2], channels[1], 2, stride=2)
        self.dec2 = BlockType(channels[2], channels[1])
        self.up1 = nn.ConvTranspose2d(channels[1], channels[0], 2, stride=2)
        self.dec1 = BlockType(channels[1], channels[0])
        if self.use_attention:
            self.att4 = AttentionGate(F_g=channels[3], F_l=channels[3], F_int=max(channels[3]//2,16))
            self.att3 = AttentionGate(F_g=channels[2], F_l=channels[2], F_int=max(channels[2]//2,16))
            self.att2 = AttentionGate(F_g=channels[1], F_l=channels[1], F_int=max(channels[1]//2,16))
            self.att1 = AttentionGate(F_g=channels[0], F_l=channels[0], F_int=max(channels[0]//2,16))
        self.out = nn.Conv2d(channels[0], 1, 1)
        if self.deep_supervision:
            self.dsv4 = nn.Conv2d(channels[3], 1, 1)
            self.dsv3 = nn.Conv2d(channels[2], 1, 1)
            self.dsv2 = nn.Conv2d(channels[1], 1, 1)
            self.dsv1 = nn.Conv2d(channels[0], 1, 1)
    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))
        b = self.bottleneck(self.pool(e4))
        d4 = self.up4(b)
        if self.use_attention: e4 = self.att4(d4, e4)
        d4 = torch.cat([d4, e4], dim=1); d4 = self.dec4(d4)
        d3 = self.up3(d4)
        if self.use_attention: e3 = self.att3(d3, e3)
        d3 = torch.cat([d3, e3], dim=1); d3 = self.dec3(d3)
        d2 = self.up2(d3)
        if self.use_attention: e2 = self.att2(d2, e2)
        d2 = torch.cat([d2, e2], dim=1); d2 = self.dec2(d2)
        d1 = self.up1(d2)
        if self.use_attention: e1 = self.att1(d1, e1)
        d1 = torch.cat([d1, e1], dim=1); d1 = self.dec1(d1)
        out = torch.sigmoid(self.out(d1))
        if self.deep_supervision and self.training:
            dsv4 = torch.sigmoid(self.dsv4(d4)); dsv3 = torch.sigmoid(self.dsv3(d3))
            dsv2 = torch.sigmoid(self.dsv2(d2)); dsv1 = torch.sigmoid(self.dsv1(d1))
            dsv4 = F.interpolate(dsv4, size=out.shape[2:], mode='bilinear', align_corners=False)
            dsv3 = F.interpolate(dsv3, size=out.shape[2:], mode='bilinear', align_corners=False)
            dsv2 = F.interpolate(dsv2, size=out.shape[2:], mode='bilinear', align_corners=False)
            return out, [dsv4,dsv3,dsv2,dsv1]
        return out

# ----------------- UNetEncoderDecoder (timm backbones) -----------------
class Conv2(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )
    def forward(self, x): return self.block(x)

class Up2(nn.Module):
    def __init__(self, in_ch, skip_ch, out_ch):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_ch, in_ch, 2, stride=2)
        self.conv = Conv2(in_ch + skip_ch, out_ch)
    def forward(self, x, skip):
        x = self.up(x)
        dy = skip.size(2) - x.size(2); dx = skip.size(3) - x.size(3)
        if dy != 0 or dx != 0:
            x = F.pad(x, [dx//2, dx-dx//2, dy//2, dy-dy//2])
        x = torch.cat([skip, x], dim=1); return self.conv(x)

class UNetEncoderDecoder(nn.Module):
    def __init__(self, backbone_name: str = "resnet34", pretrained: bool = True, in_ch: int = 1):
        super().__init__()
        self.encoder = timm.create_model(backbone_name, features_only=True, out_indices=(0,1,2,3,4), pretrained=pretrained, in_chans=in_ch)
        enc_channels = self.encoder.feature_info.channels()
        self.center = Conv2(enc_channels[-1], 512)
        self.dec4 = Up2(512, enc_channels[-2], 256)
        self.dec3 = Up2(256, enc_channels[-3], 128)
        self.dec2 = Up2(128, enc_channels[-4], 64)
        self.dec1 = Up2(64, enc_channels[-5], 32)
        self.final_conv = nn.Conv2d(32, 1, 1)
    def forward(self, x):
        feats = self.encoder(x)
        x0,x1,x2,x3,x4 = feats
        center = self.center(x4)
        d4 = self.dec4(center, x3); d3 = self.dec3(d4, x2); d2 = self.dec2(d3, x1); d1 = self.dec1(d2, x0)
        out = self.final_conv(d1); return out

def create_unet_model(backbone_name: str, pretrained: bool = False, in_ch: int = 1):
    return UNetEncoderDecoder(backbone_name=backbone_name, pretrained=pretrained, in_ch=in_ch)

# ----------------- register models -----------------
def register_models():
    MODEL_SPECS["PTXSegNet_highres"] = (lambda: PTXSegNet({'attention':True,'residual':True,'deep_supervision':False,'channels':[64,128,256,512,1024]}), 512)
    MODEL_SPECS["UNet_ResNet50_1024_focal"] = (lambda: create_unet_model("resnet50", pretrained=False, in_ch=1), 1024)
    MODEL_SPECS["UNet_EffNetB4_1024_focal"] = (lambda: create_unet_model("tf_efficientnet_b4_ns", pretrained=False, in_ch=1), 1024)
register_models()

# ----------------- checkpoint loader -----------------
def load_checkpoint_into_model(model: nn.Module, path: str, device):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    state = torch.load(path, map_location=device)
    if isinstance(state, dict):
        if 'model_state_dict' in state:
            sd = state['model_state_dict']
        elif 'state_dict' in state:
            sd = state['state_dict']
        else:
            sd = state
        new = {}
        for k,v in sd.items():
            nk = k.replace("module.", "")
            new[nk] = v
        model.load_state_dict(new, strict=False)
    else:
        model.load_state_dict(state)
    return model

# ----------------- TTA helpers -----------------
def apply_tta_tensor(img_tensor: torch.Tensor, tta_key: str):
    if tta_key == "none": return img_tensor
    if tta_key == "hflip": return torch.flip(img_tensor, dims=[2])
    return img_tensor

def inverse_tta_numpy(pred_np: np.ndarray, tta_key: str):
    if tta_key == "none": return pred_np
    if tta_key == "hflip": return np.flip(pred_np, axis=1)
    return pred_np

def predict_with_tta(model: nn.Module, img_t: torch.Tensor, device, tta_keys=TTA_KEYS):
    model.eval()
    h = img_t.shape[1]; w = img_t.shape[2]
    soft_sum = None; count = 0
    with torch.no_grad():
        for k in tta_keys:
            inp = apply_tta_tensor(img_t, k).unsqueeze(0).to(device)  # (1,1,H,W)
            out = model(inp)
            if isinstance(out, tuple): out = out[0]
            prob = torch.sigmoid(out)[0,0].cpu().numpy()
            prob = inverse_tta_numpy(prob, k)
            if prob.shape != (h,w):
                prob = cv2.resize(prob, (w,h), interpolation=cv2.INTER_LINEAR)
            if soft_sum is None:
                soft_sum = np.zeros_like(prob, dtype=np.float32)
            soft_sum += prob; count += 1
    if count == 0: raise RuntimeError("No TTA predictions")
    return (soft_sum / float(count)).astype(np.float32)

# ----------------- evaluate one model -----------------
def evaluate_model(name: str, ctor_fn, img_size: int, ckpt_path: str, image_files: List[str], mask_files: List[str], out_dir: str = OUT_DIR):
    print("\n" + "="*72)
    print(f"Running model: {name} (img_size={img_size})")
    print("="*72)
    model = ctor_fn()
    model = model.to(DEVICE)
    if os.path.isfile(ckpt_path):
        try:
            load_checkpoint_into_model(model, ckpt_path, DEVICE)
            print(f"Loaded checkpoint for {name}: {ckpt_path}")
        except Exception as e:
            print(f"Failed loading checkpoint for {name}: {e}")
            print("Continuing with randomly-initialized model (metrics will be meaningless).")
    else:
        print(f"Checkpoint not found for {name}: {ckpt_path}. Continuing with random init.")

    ds = SIIMDataset(image_files, mask_files, img_size=img_size)
    loader = DataLoader(ds, batch_size=1, shuffle=False, num_workers=2)

    preds_dir = os.path.join(out_dir, "preds", name); overlays_dir = os.path.join(out_dir, "overlays", name)
    os.makedirs(preds_dir, exist_ok=True); os.makedirs(overlays_dir, exist_ok=True)

    per_image = []; dice_list = []

    # We'll store overlay canvases and bin masks in memory and only write selected ones later.
    overlays_map: Dict[str, np.ndarray] = {}
    preds_map: Dict[str, np.ndarray] = {}

    print(f"Running inference (TTA={TTA_KEYS}) on {len(ds)} images...")
    for i, batch in enumerate(tqdm(loader)):
        try:
            # unpack (handle both tuple forms)
            if len(batch) == 4:
                img_t, mask_t, img_for_plot, fp = batch
            else:
                img_t, mask_t, img_for_plot, fp = batch[0], batch[1], batch[2], batch[3]
            # img_t: batch_dim=1 -> take 0
            img_single = img_t[0]   # torch.Tensor (1,H,W)
            mask_single = mask_t[0,0].cpu().numpy().astype(np.uint8)  # H,W

            # img_for_plot might be numpy or torch.Tensor depending on collate
            img_plot_raw = img_for_plot[0]
            if isinstance(img_plot_raw, torch.Tensor):
                img_plot = img_plot_raw.cpu().numpy()
                # if channel-first (C,H,W) convert to H,W,C
                if img_plot.ndim == 3 and img_plot.shape[0] in (1,3):
                    if img_plot.shape[0] == 1:
                        img_plot = np.squeeze(img_plot, axis=0)
                        img_plot = np.stack([img_plot,img_plot,img_plot], axis=-1)
                    else:
                        img_plot = np.transpose(img_plot, (1,2,0))
            else:
                img_plot = np.array(img_plot_raw, copy=True)

            # ensure float32 0..1 and shape H,W,3
            img_plot = img_plot.astype(np.float32)
            if img_plot.ndim == 2:
                img_plot = np.stack([img_plot,img_plot,img_plot], axis=-1)
            if img_plot.max() > 1.5:
                img_plot = img_plot / 255.0

            # predict soft map with TTA
            soft = predict_with_tta(model, img_single, DEVICE, tta_keys=TTA_KEYS)

            # postprocess
            bin_mask = postprocess_softmask(soft, threshold=THRESHOLD, min_component_size=MIN_COMPONENT_AREA)

            dice_v = dice_numpy(bin_mask, mask_single)
            iou_v = iou_numpy(bin_mask, mask_single)
            prec, rec, f1 = precision_recall_f1(bin_mask, mask_single)
            case_gt = int(mask_single.sum() > 0); case_pred = int(bin_mask.sum() > 0)
            acc = float((bin_mask == mask_single).sum()) / mask_single.size
            TP = int(((bin_mask==1) & (mask_single==1)).sum())
            TN = int(((bin_mask==0) & (mask_single==0)).sum())
            FP = int(((bin_mask==1) & (mask_single==0)).sum())
            FN = int(((bin_mask==0) & (mask_single==1)).sum())

            # create overlays in memory
            gt_overlay = overlay_image_with_mask(img_plot, mask_single, color=(0.0,0.0,1.0), alpha=0.6)
            pred_overlay = overlay_image_with_mask(img_plot, bin_mask, color=(1.0,1.0,0.0), alpha=0.6)
            error_mask = ((bin_mask.astype(np.uint8) ^ mask_single.astype(np.uint8))>0).astype(np.uint8)
            error_overlay = overlay_image_with_mask(img_plot, error_mask, color=(1.0,0.0,0.0), alpha=0.7)

            h,w,_ = img_plot.shape
            canvas = np.zeros((h*3, w, 3), dtype=np.uint8)
            canvas[0:h]   = (gt_overlay * 255).astype(np.uint8)
            canvas[h:2*h] = (pred_overlay * 255).astype(np.uint8)
            canvas[2*h:3*h] = (error_overlay * 255).astype(np.uint8)

            file_stem = Path(fp[0]).stem
            overlays_map[fp[0]] = canvas  # store RGB uint8 canvas
            preds_map[fp[0]] = (bin_mask * 255).astype(np.uint8)  # store uint8 mask

            per_image.append({
                'model': name,
                'image': fp[0],
                'dice': float(dice_v),
                'iou': float(iou_v),
                'pix_precision': float(prec),
                'pix_recall': float(rec),
                'pix_f1': float(f1),
                'pixel_accuracy': float(acc),
                'case_gt': int(case_gt),
                'case_pred': int(case_pred),
                'TP': TP, 'TN': TN, 'FP': FP, 'FN': FN,
                'threshold': float(THRESHOLD),
                'min_component_size': int(MIN_COMPONENT_AREA),
                'pred_mask_path': None,   # will be filled for selected only
                'overlay_path': None
            })
            dice_list.append(dice_v)

        except Exception as e:
            # don't stop whole run; record error row
            fp_val = None
            try:
                fp_val = fp[0]
            except Exception:
                pass
            print(f"Error during inference for {name} on {fp_val}: {e}")
            per_image.append({
                'model': name,
                'image': fp_val,
                'dice': None,
                'iou': None,
                'pix_precision': None,
                'pix_recall': None,
                'pix_f1': None,
                'pixel_accuracy': None,
                'case_gt': None,
                'case_pred': None,
                'TP': None, 'TN': None, 'FP': None, 'FN': None,
                'threshold': float(THRESHOLD),
                'min_component_size': int(MIN_COMPONENT_AREA),
                'pred_mask_path': None,
                'overlay_path': None,
                'error': str(e)
            })
            continue

    # After inference: select top3 (best, median, worst) among case_gt == 1
    pos_rows = [r for r in per_image if isinstance(r.get('case_gt'), (int, np.integer)) and r['case_gt'] == 1 and r.get('dice') is not None]
    if len(pos_rows) == 0:
        print(f"[WARN] No positive (label=1) images found for model {name}. No overlays will be saved.")
        selected_keys = []
    else:
        pos_sorted = sorted(pos_rows, key=lambda r: r['dice'], reverse=True)
        # best, median, worst index selection
        best = pos_sorted[0]
        worst = pos_sorted[-1]
        median = pos_sorted[len(pos_sorted)//2]
        # If fewer than 3 unique images, dedupe
        selected = []
        for r in (best, median, worst):
            if r['image'] not in selected:
                selected.append(r['image'])
        selected_keys = selected

    # Write selected overlays & preds to disk and update per_image rows with paths
    for img_fp in selected_keys:
        canvas = overlays_map.get(img_fp)
        pred_mask = preds_map.get(img_fp)
        if canvas is not None:
            out_overlay = os.path.join(overlays_dir, f"{Path(img_fp).stem}_overlay.png")
            cv2.imwrite(out_overlay, cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR))
        else:
            out_overlay = None
        if pred_mask is not None:
            out_pred = os.path.join(preds_dir, f"{Path(img_fp).stem}_pred.png")
            cv2.imwrite(out_pred, pred_mask)
        else:
            out_pred = None

        # update per_image entry for this image
        for r in per_image:
            if r['image'] == img_fp:
                r['pred_mask_path'] = out_pred
                r['overlay_path'] = out_overlay

    # compute summary
    dice_arr = np.array([d for d in dice_list if d is not None], dtype=np.float32) if len(dice_list)>0 else np.array([])
    summary = {'model': name, 'N': len(per_image), 'MeanDice': float(np.mean(dice_arr)) if dice_arr.size>0 else None, 'StdDice': float(np.std(dice_arr)) if dice_arr.size>0 else None}

    # aggregate case-level confusion across valid rows
    TP = sum([r['TP'] for r in per_image if isinstance(r.get('TP'), (int, np.integer))])
    TN = sum([r['TN'] for r in per_image if isinstance(r.get('TN'), (int, np.integer))])
    FP = sum([r['FP'] for r in per_image if isinstance(r.get('FP'), (int, np.integer))])
    FN = sum([r['FN'] for r in per_image if isinstance(r.get('FN'), (int, np.integer))])

    case_gt_list = [r['case_gt'] for r in per_image if isinstance(r.get('case_gt'), (int, np.integer))]
    case_pred_list = [r['case_pred'] for r in per_image if isinstance(r.get('case_pred'), (int, np.integer))]
    try:
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
        if len(case_gt_list) > 0:
            acc_case = accuracy_score(case_gt_list, case_pred_list)
            prec_case = precision_score(case_gt_list, case_pred_list, zero_division=0)
            rec_case = recall_score(case_gt_list, case_pred_list, zero_division=0)
            f1_case = f1_score(case_gt_list, case_pred_list, zero_division=0)
            tn_c, fp_c, fn_c, tp_c = confusion_matrix(case_gt_list, case_pred_list, labels=[0,1]).ravel()
        else:
            acc_case = prec_case = rec_case = f1_case = None
            tn_c=fp_c=fn_c=tp_c=0
    except Exception:
        acc_case = prec_case = rec_case = f1_case = None
        tn_c=fp_c=fn_c=tp_c=0

    summary.update({
        'MeanIoU': float(np.mean([r['iou'] for r in per_image if r.get('iou') is not None])) if any(r.get('iou') is not None for r in per_image) else None,
        'PixPrec': float(np.mean([r['pix_precision'] for r in per_image if r.get('pix_precision') is not None])) if any(r.get('pix_precision') is not None for r in per_image) else None,
        'PixRec' : float(np.mean([r['pix_recall'] for r in per_image if r.get('pix_recall') is not None])) if any(r.get('pix_recall') is not None for r in per_image) else None,
        'PixF1'  : float(np.mean([r['pix_f1'] for r in per_image if r.get('pix_f1') is not None])) if any(r.get('pix_f1') is not None for r in per_image) else None,
        'CaseAcc': acc_case, 'CasePrec': prec_case, 'CaseRec': rec_case, 'CaseF1': f1_case,
        'Spec': (tn_c / (tn_c + fp_c) if (tn_c + fp_c)>0 else None),
        'TN': int(tn_c), 'FP': int(fp_c), 'FN': int(fn_c), 'TP': int(tp_c),
        'DiceLoss': None, 'DiceBefore': None
    })

    # Return per-image rows and summary
    return per_image, summary

# ----------------- helpers to collect files -----------------
def collect_image_mask_list(data_root: str):
    imgs_dir = os.path.join(data_root, "test", "png_images")
    masks_dir = os.path.join(data_root, "test", "png_masks")
    if not os.path.isdir(imgs_dir) or not os.path.isdir(masks_dir):
        raise RuntimeError(f"Expected test png_images & png_masks under {data_root}/test")
    img_files = sorted(glob.glob(os.path.join(imgs_dir, "*.png")))
    mask_files = []
    for p in img_files:
        mask_path = p.replace(os.path.join("test","png_images"), os.path.join("test","png_masks")).replace("image_", "mask_")
        if os.path.exists(mask_path):
            mask_files.append(mask_path)
        else:
            raise RuntimeError(f"Missing mask for {p}: expected {mask_path}")
    return img_files, mask_files

# ----------------- main -----------------
def main():
    image_files, mask_files = collect_image_mask_list(DATA_ROOT)
    all_per_image = []; summaries = []
    for model_key, spec in MODEL_SPECS.items():
        ctor_fn, img_size = spec
        ckpt_path = CHECKPOINTS.get(model_key, "")
        per_image, summary = evaluate_model(model_key, ctor_fn, img_size, ckpt_path, image_files, mask_files, out_dir=OUT_DIR)
        all_per_image.extend(per_image); summaries.append(summary)

    # save per-image CSV
    import csv
    per_csv = os.path.join(OUT_DIR, "per_image_metrics.csv")
    if len(all_per_image) > 0:
        keys = list(all_per_image[0].keys())
        with open(per_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for r in all_per_image:
                writer.writerow(r)
        print(f"Wrote per-image CSV: {per_csv}")

    # save summary CSV
    sum_csv = os.path.join(OUT_DIR, "summary_metrics.csv")
    if len(summaries) > 0:
        keys = sorted(list({k for s in summaries for k in s.keys()}))
        with open(sum_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for s in summaries:
                writer.writerow(s)
        print(f"Wrote summary CSV: {sum_csv}")

    # pretty print summary table
    cols = ["model","N","MeanDice","StdDice","MeanIoU","PixPrec","PixRec","PixF1","CaseAcc","CasePrec","CaseRec","CaseF1","Spec","TN","FP","FN","TP"]
    header = " | ".join([f"{c:>12}" for c in cols])
    print("\n" + "="*80)
    print("FINAL COMPARISON REPORT")
    print(header)
    print("-"*len(header))
    for s in summaries:
        vals = []
        for c in cols:
            v = s.get(c)
            if isinstance(v, float):
                vals.append(f"{v:12.4f}")
            else:
                vals.append(f"{str(v):>12}")
        print(" | ".join(vals))

    print("\nDone. Outputs:")
    print(f" - summary CSV: {sum_csv}")
    print(f" - per-image CSV: {per_csv}")
    print(f" - overlays & preds in: {OUT_DIR}")

if __name__ == "__main__":
    main()
