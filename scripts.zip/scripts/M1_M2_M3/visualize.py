# visualise_comparison_fixed.py
"""
Updated multi-model comparison visualization script.
Fixes common issues with DataLoader collation, dtypes/shapes, mask/pred resizing
and more. Drop-in replacement for your original visualise_comparison.py.

Notes:
 - Make sure timm is installed and the checkpoints exist.
 - I set DataLoader num_workers=0 to avoid subtle OpenCV numpy sharing issues;
   you can increase it after verifying correctness.
"""
import os
import glob
from typing import Optional, Tuple, List, Dict, Any

import numpy as np
import cv2
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.utils.data import Dataset, DataLoader
import albumentations as A
from albumentations.pytorch import ToTensorV2
import timm
import matplotlib.pyplot as plt

# ----------------- CONFIG -----------------

class Config:
    dataset_root = "/media/admin1/DL/shubham/FYP_2.0/final_dataset"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    threshold = 0.5
    batch_size = 4
    num_workers = 0  # set to 0 for stability; increase when stable
    output_dir = "new_new"

    models = [
        {
            'name': 'ptxseg_net_high_lr',
            'ckpt_path': 'checkpoints/ptxseg_net_high_lr_best.pth',
            'model_name': 'unet_resnet34',
            'img_size': 512,
            'attention': True,
            'residual': True,
            'deep_supervision': True,
        },
        {
            'name': 'unet_r50_1024_focal',
            'ckpt_path': 'checkpoints/unet_r50_1024_focal.pth',
            'model_name': 'unet_resnet50',
            'img_size': 1024,
            'attention': False,
            'residual': False,
            'deep_supervision': False,
        },
        {
            'name': 'unet_effnet_b4_1024_focal',
            'ckpt_path': 'checkpoints/unet_effnet_b4_1024_focal.pth',
            'model_name': 'unet_effnet_b4',
            'img_size': 1024,
            'attention': False,
            'residual': False,
            'deep_supervision': False,
        },
    ]


cfg = Config()
os.makedirs(cfg.output_dir, exist_ok=True)


# ----------------- DATASET -----------------

class PneumothoraxDataset(Dataset):
    def __init__(self, root_dir: str, split: str = "test", transforms=None, img_size: int = 512):
        super().__init__()
        assert split in ["train", "test"]
        self.root_dir = root_dir
        self.split = split
        self.transforms = transforms
        self.img_size = img_size

        img_dir = os.path.join(root_dir, split, "png_images")
        self.img_paths = sorted(glob.glob(os.path.join(img_dir, "*.png")))
        if len(self.img_paths) == 0:
            raise RuntimeError(f"No PNG images found in {img_dir}")

    def __len__(self):
        return len(self.img_paths)

    def _get_mask_path(self, img_path: str) -> str:
        mask_path = img_path.replace(
            os.path.join(self.split, "png_images"),
            os.path.join(self.split, "png_masks")
        )
        mask_path = mask_path.replace("image_", "mask_")
        return mask_path

    def __getitem__(self, idx):
        img_path = self.img_paths[idx]
        mask_path = self._get_mask_path(img_path)

        # Read image (grayscale chest x-ray)
        image = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)
        if image is None:
            raise RuntimeError(f"Failed to read image: {img_path}")

        # Convert to grayscale if needed
        if image.ndim == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Convert to uint8 if needed and keep ORIGINAL for plotting
        if image.dtype != np.uint8:
            image = cv2.normalize(image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

        # Read mask (binary)
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise RuntimeError(f"Failed to read mask: {mask_path}")
        mask = (mask > 0).astype(np.uint8)  # binary uint8

        # Prepare img_for_plot: resized, converted to RGB and scaled to [0,1] float32
        img_for_plot = cv2.resize(image, (self.img_size, self.img_size))
        img_for_plot = cv2.cvtColor(img_for_plot, cv2.COLOR_GRAY2RGB).astype(np.float32) / 255.0

        # Prepare model input (single channel float32 in [0,1])
        img_model = cv2.resize(image, (self.img_size, self.img_size)).astype(np.float32) / 255.0
        img_model = np.expand_dims(img_model, axis=-1)  # HWC (H, W, 1)

        # Resize mask to model img_size
        mask_model = cv2.resize(mask.astype(np.uint8) * 255, (self.img_size, self.img_size), interpolation=cv2.INTER_NEAREST)
        mask_model = (mask_model > 0).astype(np.float32)  # H,W, as float32

        if self.transforms is not None:
            # Albumentations expects image in HWC (0-255) usually; we already provided [0,1].
            # But Normalize expects 0-255 by default. Since we used float [0,1], we'll use transforms that
            # handle that by specifying always_apply=False. To keep things robust, we will pass images in [0,255].
            # So convert back temporarily for transforms and then re-normalize to tensor below.
            image_for_aug = (img_model[..., 0] * 255.0).astype(np.uint8)
            mask_for_aug = (mask_model).astype(np.uint8)

            augmented = self.transforms(image=image_for_aug, mask=mask_for_aug)
            img_aug = augmented["image"]  # this is a tensor because ToTensorV2 used
            mask_aug = augmented["mask"]  # this is a tensor (H,W) or (1,H,W)

            # Ensure channel-first float tensor for image: (1,H,W), float
            if isinstance(img_aug, torch.Tensor):
                if img_aug.ndim == 3 and img_aug.shape[0] != 1:
                    # if img_aug is (3,H,W) because we converted to single channel incorrectly
                    img_aug = img_aug[0:1, :, :]  # take first channel
                image_tensor = img_aug.float()
            else:
                # fallback
                image_tensor = torch.from_numpy(np.expand_dims(img_aug, 0).astype(np.float32) / 255.0)

            # Mask -> (1,H,W) float
            if isinstance(mask_aug, torch.Tensor):
                if mask_aug.ndim == 2:
                    mask_tensor = mask_aug.unsqueeze(0).float()
                elif mask_aug.ndim == 3 and mask_aug.shape[0] != 1:
                    mask_tensor = mask_aug[0:1, :, :].float()
                else:
                    mask_tensor = mask_aug.float()
            else:
                mask_tensor = torch.from_numpy(np.expand_dims(mask_aug, 0).astype(np.float32))

        else:
            # Without albumentations: convert to tensors directly (channel-first)
            image_tensor = torch.from_numpy(img_model.transpose(2, 0, 1)).float()
            mask_tensor = torch.from_numpy(mask_model[None, ...].astype(np.float32))

        # Sanity: ensure shapes
        assert image_tensor.ndim == 3 and image_tensor.shape[0] == 1, f"Image shape unexpected: {image_tensor.shape}"
        assert mask_tensor.ndim == 3 and mask_tensor.shape[0] == 1, f"Mask shape unexpected: {mask_tensor.shape}"

        # Return: image tensor, mask tensor, img_for_plot (numpy float32 [0,1]), img_path
        return image_tensor, mask_tensor, img_for_plot.astype(np.float32), img_path


def get_test_transforms(img_size: int):
    # We will feed albumentations images as uint8 [0,255] so Normalize uses mean/std in 0-255 domain
    return A.Compose(
        [
            A.Resize(img_size, img_size),
            # No brightness/contrast augmentation: this is test-time transform.
            A.Normalize(mean=(127.5,), std=(127.5,)),  # scale to ~[-1,1] if desired
            ToTensorV2(),
        ]
    )


# ----------------- MODEL -----------------

class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class UpBlock(nn.Module):
    def __init__(self, in_channels, skip_channels, out_channels):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_channels, in_channels, 2, stride=2)
        self.conv = ConvBlock(in_channels + skip_channels, out_channels)

    def forward(self, x, skip):
        x = self.up(x)
        # pad if needed
        diff_y = skip.size(2) - x.size(2)
        diff_x = skip.size(3) - x.size(3)
        if diff_y != 0 or diff_x != 0:
            x = F.pad(
                x,
                [diff_x // 2, diff_x - diff_x // 2,
                 diff_y // 2, diff_y - diff_y // 2],
            )
        x = torch.cat([skip, x], dim=1)
        x = self.conv(x)
        return x


class UNetEncoderDecoder(nn.Module):
    def __init__(self, backbone_name: str = "resnet34", pretrained: bool = True):
        super().__init__()
        # Create timm model that returns feature maps at multiple scales.
        # in_chans=1 is used because input is single-channel chest x-ray.
        self.encoder = timm.create_model(
            backbone_name,
            features_only=True,
            out_indices=(0, 1, 2, 3, 4),
            pretrained=pretrained,
            in_chans=1,
        )
        enc_channels = self.encoder.feature_info.channels()

        # center and decoder sizes tuned to channels produced by encoder
        # Set center to last channel -> reduce / decode progressively
        self.center = ConvBlock(enc_channels[-1], 512)
        self.dec4 = UpBlock(512, enc_channels[-2], 256)
        self.dec3 = UpBlock(256, enc_channels[-3], 128)
        self.dec2 = UpBlock(128, enc_channels[-4], 64)
        self.dec1 = UpBlock(64, enc_channels[-5], 32)

        self.final_conv = nn.Conv2d(32, 1, kernel_size=1)

    def forward(self, x):
        # Expect x shape: (B,1,H,W)
        features = self.encoder(x)
        # features: list [x0,x1,x2,x3,x4]
        x0, x1, x2, x3, x4 = features
        center = self.center(x4)
        d4 = self.dec4(center, x3)
        d3 = self.dec3(d4, x2)
        d2 = self.dec2(d3, x1)
        d1 = self.dec1(d2, x0)
        out = self.final_conv(d1)
        return out


def create_model(model_name: str, pretrained: bool = False) -> nn.Module:
    backbone_map = {
        "unet_resnet34": "resnet34",
        "unet_resnet50": "resnet50",
        "unet_effnet_b0": "tf_efficientnet_b0_ns",
        "unet_effnet_b4": "tf_efficientnet_b4_ns",
        "unet_effnet_b7": "tf_efficientnet_b7_ns",
    }

    if model_name not in backbone_map:
        raise ValueError(f"Unknown model_name: {model_name}")

    return UNetEncoderDecoder(backbone_name=backbone_map[model_name], pretrained=pretrained)


# ----------------- METRICS -----------------

def dice_score_tensor(pred: torch.Tensor, target: torch.Tensor, smooth: float = 1e-6) -> float:
    """Calculate dice score between prediction and target (both binary float tensors)."""
    pred = pred.view(-1).float()
    target = target.view(-1).float()
    inter = (pred * target).sum()
    denom = pred.sum() + target.sum()
    if denom.item() == 0:
        # both empty masks -> considered perfect
        return 1.0
    return ((2.0 * inter + smooth) / (denom + smooth)).item()


# ----------------- COMPUTE DICE PER IMAGE -----------------

def _default_collate(batch: List[Any]):
    """
    Custom collate: stack tensors, keep lists for img_for_plot and paths.
    Each item = (image_tensor, mask_tensor, img_for_plot(np), img_path(str))
    """
    images = torch.stack([b[0] for b in batch], dim=0)
    masks = torch.stack([b[1] for b in batch], dim=0)
    imgs_for_plot = [b[2] for b in batch]
    img_paths = [b[3] for b in batch]
    return images, masks, imgs_for_plot, img_paths


def compute_dice_per_image(
    model: nn.Module,
    dataset: PneumothoraxDataset,
    batch_size: int = 4,
    num_workers: int = 0
) -> Tuple[List[str], List[float], Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """
    Compute dice score for each image in the dataset and return maps.
    """
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        collate_fn=_default_collate
    )
    dice_list: List[float] = []
    file_list: List[str] = []
    preds_map: Dict[str, np.ndarray] = {}
    img_plot_map: Dict[str, np.ndarray] = {}

    model.eval()
    print(f"Computing dice scores for all images (img_size={dataset.img_size})...")

    with torch.no_grad():
        for images, masks, imgs_for_plot, img_paths in tqdm(loader, desc="Processing"):
            # images: (B,1,H,W) float
            images = images.to(cfg.device)
            masks = masks.to(cfg.device)  # (B,1,H,W)

            logits = model(images)  # (B,1,H',W')
            # Ensure logits are same spatial size as masks
            if logits.shape[2:] != masks.shape[2:]:
                logits = F.interpolate(logits, size=masks.shape[2:], mode="bilinear", align_corners=False)

            probs = torch.sigmoid(logits)
            preds = (probs > cfg.threshold).float()  # (B,1,H,W)

            B = preds.shape[0]
            for i in range(B):
                pred_tensor = preds[i, 0]  # (H,W)
                mask_tensor = masks[i, 0]  # (H,W)

                # Ensure binary uint8 maps for storage
                pred_np = (pred_tensor.cpu().numpy() > 0.5).astype(np.uint8)
                mask_np = (mask_tensor.cpu().numpy() > 0.5).astype(np.uint8)

                # Dice on float tensors (0..1)
                dice_val = dice_score_tensor(torch.from_numpy(pred_np.astype(np.float32)), torch.from_numpy(mask_np.astype(np.float32)))

                img_path = img_paths[i]
                dice_list.append(dice_val)
                file_list.append(img_path)
                preds_map[img_path] = pred_np  # uint8 binary
                # store the plotting image (already [0,1] float)
                img_plot_map[img_path] = imgs_for_plot[i]

    return file_list, dice_list, preds_map, img_plot_map


# ----------------- SELECT SAMPLES -----------------

def pick_samples_for_ranges(
    file_list: List[str],
    dice_list: List[float],
    masks_map: Dict[str, np.ndarray]
) -> Tuple[int, int, int]:
    """
    Select best, median, and worst samples from positive mask images.
    """
    positive_items = []
    for i, img_path in enumerate(file_list):
        mask = masks_map.get(img_path)
        if mask is not None and np.any(mask > 0):
            positive_items.append((i, dice_list[i]))

    if len(positive_items) == 0:
        raise RuntimeError("No positive-mask images found in dataset.")

    print(f"Found {len(positive_items)} positive samples")

    # Sort descending
    positive_items = sorted(positive_items, key=lambda x: x[1], reverse=True)

    best_idx = positive_items[0][0]
    worst_idx = positive_items[-1][0]
    med_idx = positive_items[len(positive_items) // 2][0]

    print(f"Best dice: {dice_list[best_idx]:.4f}, Med: {dice_list[med_idx]:.4f}, Worst: {dice_list[worst_idx]:.4f}")

    return best_idx, med_idx, worst_idx


# ----------------- OVERLAY HELPERS -----------------

def overlay_image_with_mask(
    img: np.ndarray,
    mask: np.ndarray,
    color: Tuple[float, float, float],
    alpha: float = 0.6
) -> np.ndarray:
    """
    Overlay colored mask on image.
    img: HxWx3 float in [0,1]
    mask: HxW binary (0 or 1) or float in [0,1]
    color: tuple float 0..1 RGB
    returns: HxWx3 float in [0,1]
    """
    if isinstance(img, torch.Tensor):
        img = img.cpu().numpy()
    img = img.copy().astype(np.float32)
    if img.max() > 1.1:
        # If was in 0-255 scale, convert
        img = np.clip(img / 255.0, 0.0, 1.0)

    # mask -> 0..1
    if mask.dtype != np.float32:
        mask = mask.astype(np.float32)
    if mask.ndim == 3:
        mask = mask.squeeze()
    mask = (mask > 0.5).astype(np.float32)

    colored_mask = np.stack([mask * color[0], mask * color[1], mask * color[2]], axis=-1)

    out = img * (1.0 - alpha * np.expand_dims(mask, -1)) + colored_mask * alpha
    out = np.clip(out, 0.0, 1.0)
    return out


# ----------------- VISUALIZATION -----------------

def visualize_multi_model_comparison(model_results: List[Dict]):
    """
    Create comparison plots for best/medium/worst dice scores across multiple models.
    """
    if len(model_results) == 0:
        raise RuntimeError("No model results provided")

    # Use first model's masks_map (they all share same filenames)
    reference_mr = model_results[0]
    best_idx, med_idx, worst_idx = pick_samples_for_ranges(
        reference_mr["file_list"],
        reference_mr["dice_list"],
        reference_mr["masks_map"]
    )

    sample_indices = {"best": best_idx, "med": med_idx, "worst": worst_idx}
    ranges = [("best", "High (Best)"), ("med", "Medium (Median)"), ("worst", "Poor (Worst)")]
    color_gt = (0.0, 0.5, 1.0)      # blue
    color_pred = (1.0, 0.9, 0.0)    # yellow
    color_error = (1.0, 0.0, 0.0)   # red

    for rkey, rtitle in ranges:
        idx = sample_indices[rkey]
        num_models = len(model_results)
        fig, axes = plt.subplots(3, num_models, figsize=(6 * num_models, 16))

        if num_models == 1:
            axes = axes.reshape(3, 1)

        for col, mr in enumerate(model_results):
            model_name = mr["name"]
            img_path = mr["file_list"][idx]
            dice = mr["dice_list"][idx]

            # Data
            mask_np = mr["masks_map"].get(img_path)
            pred_np = mr["preds_map"].get(img_path)
            img_for_plot = mr["img_plot_map"].get(img_path)

            if mask_np is None or pred_np is None or img_for_plot is None:
                raise RuntimeError(f"Missing data for {img_path} in model {model_name}")

            # ensure 2D
            if mask_np.ndim > 2:
                mask_np = mask_np.squeeze()
            if pred_np.ndim > 2:
                pred_np = pred_np.squeeze()

            # error map: XOR (difference)
            error_np = ((pred_np.astype(np.uint8) ^ mask_np.astype(np.uint8)) > 0).astype(np.float32)

            gt_overlay = overlay_image_with_mask(img_for_plot, mask_np, color=color_gt, alpha=0.5)
            pred_overlay = overlay_image_with_mask(img_for_plot, pred_np, color=color_pred, alpha=0.5)
            error_overlay = overlay_image_with_mask(img_for_plot, error_np, color=color_error, alpha=0.6)

            axes[0, col].imshow(gt_overlay)
            axes[0, col].set_title(f"{model_name}\nGT Overlay (Blue)\nDice: {dice:.4f}", fontsize=11, fontweight='bold')
            axes[0, col].axis("off")

            axes[1, col].imshow(pred_overlay)
            axes[1, col].set_title("Predicted Overlay (Yellow)", fontsize=11)
            axes[1, col].axis("off")

            axes[2, col].imshow(error_overlay)
            axes[2, col].set_title("Error Overlay (Red)", fontsize=11)
            axes[2, col].axis("off")

        fig.suptitle(f"Dice Score Range: {rtitle}", fontsize=18, fontweight='bold')
        plt.tight_layout(rect=[0, 0, 1, 0.97])

        out_path = os.path.join(cfg.output_dir, f"comparison_{rkey}.png")
        plt.savefig(out_path, dpi=200, bbox_inches='tight')
        print(f"✓ Saved: {out_path}")
        plt.close(fig)


# ----------------- MAIN -----------------

def main():
    print(f"\n{'='*70}")
    print(f"Multi-Model Pneumothorax Segmentation Comparison (Fixed)")
    print(f"{'='*70}\n")

    model_results = []

    for model_cfg in cfg.models:
        print(f"\n{'─'*70}")
        print(f"Processing: {model_cfg['name']}")
        print(f"{'─'*70}")

        if not os.path.isfile(model_cfg['ckpt_path']):
            print(f"⚠ WARNING: Checkpoint not found: {model_cfg['ckpt_path']}")
            print(f"⚠ Skipping model: {model_cfg['name']}\n")
            continue

        transforms = get_test_transforms(model_cfg['img_size'])
        dataset = PneumothoraxDataset(
            cfg.dataset_root,
            split="test",
            transforms=transforms,
            img_size=model_cfg['img_size']
        )
        print(f"✓ Found {len(dataset)} test images")

        try:
            model = create_model(model_cfg['model_name'], pretrained=False).to(cfg.device)
            checkpoint = torch.load(model_cfg['ckpt_path'], map_location=cfg.device)

            # get state_dict safely
            if isinstance(checkpoint, dict):
                if 'model_state_dict' in checkpoint:
                    state_dict = checkpoint['model_state_dict']
                elif 'state_dict' in checkpoint:
                    state_dict = checkpoint['state_dict']
                else:
                    state_dict = checkpoint
            else:
                state_dict = checkpoint

            # strip 'module.' if present
            new_state_dict = {}
            for k, v in state_dict.items():
                new_k = k.replace('module.', '') if k.startswith('module.') else k
                new_state_dict[new_k] = v

            # load and report missing keys
            missing, unexpected = model.load_state_dict(new_state_dict, strict=False)
            print(f"✓ Loaded weights from checkpoint (missing keys: {len(missing)}, unexpected keys: {len(unexpected)})")

            if isinstance(checkpoint, dict):
                if 'best_dice' in checkpoint:
                    try:
                        print(f"  └─ Checkpoint best dice: {checkpoint['best_dice']:.4f}")
                    except:
                        pass
                if 'epoch' in checkpoint:
                    print(f"  └─ Epoch: {checkpoint['epoch']}")

        except Exception as e:
            print(f"✗ ERROR loading model: {str(e)}")
            print(f"✗ Skipping this model...\n")
            continue

        # compute dice
        file_list, dice_list, preds_map, img_plot_map = compute_dice_per_image(
            model, dataset, batch_size=cfg.batch_size, num_workers=cfg.num_workers
        )

        # Build masks_map from disk resized to the model's img_size
        masks_map = {}
        for img_path in file_list:
            mask_path = dataset._get_mask_path(img_path)
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
            if mask is None:
                masks_map[img_path] = np.zeros((model_cfg['img_size'], model_cfg['img_size']), dtype=np.uint8)
            else:
                mask_resized = cv2.resize((mask > 0).astype(np.uint8) * 255, (model_cfg['img_size'], model_cfg['img_size']), interpolation=cv2.INTER_NEAREST)
                masks_map[img_path] = (mask_resized > 0).astype(np.uint8)

        print(f"\n📊 Dice Score Statistics for {model_cfg['name']}:")
        print(f"  ├─ Mean:  {np.mean(dice_list):.4f}")
        print(f"  ├─ Std:   {np.std(dice_list):.4f}")
        print(f"  ├─ Min:   {np.min(dice_list):.4f}")
        print(f"  └─ Max:   {np.max(dice_list):.4f}")

        model_results.append({
            'name': model_cfg['name'],
            'file_list': file_list,
            'dice_list': dice_list,
            'preds_map': preds_map,
            'img_plot_map': img_plot_map,
            'masks_map': masks_map,
        })

    if len(model_results) == 0:
        raise RuntimeError("\n✗ No models were successfully loaded. Check checkpoint paths and model names.")

    print(f"\n{'='*70}")
    print(f"Creating comparison visualizations...")
    print(f"{'='*70}\n")

    visualize_multi_model_comparison(model_results)

    print(f"\n{'='*70}")
    print(f"✓ Done! Check output directory: {cfg.output_dir}")
    print(f"{'='*70}\n")


if __name__ == "__main__":
    main()
