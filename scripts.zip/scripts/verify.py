# Add this verification function after loading the model

def verify_model_predictions(model, dataset, device, threshold=0.5, num_samples=5):
    """
    Verify model is producing non-zero predictions.
    """
    print("\n--- Model Prediction Verification ---")
    model.eval()
    
    loader = DataLoader(dataset, batch_size=1, shuffle=False)
    
    with torch.no_grad():
        for i, (image, mask, img_plot, img_path) in enumerate(loader):
            if i >= num_samples:
                break
                
            # Check if mask has positive pixels
            if mask.sum() == 0:
                continue
                
            image = image.to(device)
            logits = model(image)
            
            if logits.shape[2:] != mask.shape[2:]:
                logits = F.interpolate(
                    logits,
                    size=mask.shape[2:],
                    mode="bilinear",
                    align_corners=False
                )
            
            probs = torch.sigmoid(logits)
            pred = (probs > threshold).float()
            
            print(f"\nSample {i+1}:")
            print(f"  Image path: {os.path.basename(img_path[0])}")
            print(f"  Input shape: {image.shape}")
            print(f"  Logits shape: {logits.shape}")
            print(f"  Logits range: [{logits.min():.3f}, {logits.max():.3f}]")
            print(f"  Probs range: [{probs.min():.3f}, {probs.max():.3f}]")
            print(f"  GT mask pixels: {mask.sum().item()}")
            print(f"  Pred mask pixels: {pred.sum().item()}")
            
            if pred.sum() == 0:
                print(f"  ⚠️ WARNING: Model produced ZERO predictions!")
                print(f"  Check: normalization, image preprocessing, model weights")
    
    print("\n" + "="*50)


# Modified main() function with better error handling:

def main():
    model_results = []
    
    for model_cfg in cfg.models:
        print(f"\n{'='*60}")
        print(f"Processing model: {model_cfg['name']}")
        print(f"{'='*60}")
        
        # Check if checkpoint exists
        if not os.path.isfile(model_cfg['ckpt_path']):
            print(f"WARNING: Checkpoint not found: {model_cfg['ckpt_path']}")
            print(f"Skipping model: {model_cfg['name']}")
            continue
        
        # Create dataset with appropriate image size
        transforms = get_test_transforms(model_cfg['img_size'])
        dataset = PneumothoraxDataset(
            cfg.dataset_root, 
            split="test", 
            transforms=transforms,
            img_size=model_cfg['img_size']
        )
        print(f"Found {len(dataset)} test images")
        
        # Load model
        try:
            model = create_model(model_cfg['model_name'], pretrained=False).to(cfg.device)
            checkpoint = torch.load(model_cfg['ckpt_path'], map_location=cfg.device, weights_only=False)
            
            # Handle different checkpoint formats
            if isinstance(checkpoint, dict):
                if 'model_state_dict' in checkpoint:
                    state_dict = checkpoint['model_state_dict']
                elif 'state_dict' in checkpoint:
                    state_dict = checkpoint['state_dict']
                else:
                    state_dict = checkpoint
            else:
                state_dict = checkpoint
            
            # Remove 'module.' prefix if present
            new_state_dict = {}
            for k, v in state_dict.items():
                new_key = k.replace("module.", "") if k.startswith("module.") else k
                new_state_dict[new_key] = v
            
            # Load with strict=True to catch mismatches
            try:
                model.load_state_dict(new_state_dict, strict=True)
                print(f"✓ Successfully loaded weights from {model_cfg['ckpt_path']}")
            except RuntimeError as e:
                print(f"⚠️ WARNING: State dict mismatch (trying strict=False)")
                print(f"Error: {e}")
                missing, unexpected = model.load_state_dict(new_state_dict, strict=False)
                if missing:
                    print(f"Missing keys: {missing[:5]}...")  # Show first 5
                if unexpected:
                    print(f"Unexpected keys: {unexpected[:5]}...")
                print("⚠️ Model may not work correctly!")
            
            # Print checkpoint info
            if isinstance(checkpoint, dict):
                if 'best_dice' in checkpoint:
                    print(f"Checkpoint best dice: {checkpoint['best_dice']:.4f}")
                if 'epoch' in checkpoint:
                    print(f"Checkpoint epoch: {checkpoint['epoch']}")
            
            # VERIFY MODEL PRODUCES NON-ZERO PREDICTIONS
            verify_model_predictions(model, dataset, cfg.device, cfg.threshold, num_samples=5)
                
        except Exception as e:
            print(f"ERROR loading model {model_cfg['name']}: {str(e)}")
            import traceback
            traceback.print_exc()
            print(f"Skipping this model...")
            continue
        
        # Compute dice scores for all images
        file_list, dice_list, preds_map, img_plot_map = compute_dice_per_image(
            model, dataset, batch_size=cfg.batch_size
        )
        
        # Check if model produced any predictions
        total_pred_pixels = sum(pred.sum() for pred in preds_map.values())
        if total_pred_pixels == 0:
            print(f"\n⚠️ CRITICAL WARNING: Model '{model_cfg['name']}' produced ZERO predictions across ALL images!")
            print("Possible issues:")
            print("  1. Wrong model architecture (attention/residual/deep_supervision not implemented)")
            print("  2. Incorrect normalization (check mean/std values)")
            print("  3. Wrong image preprocessing")
            print("  4. Checkpoint from different model architecture")
            print("  5. Model not properly trained")
            print("\nSkipping this model from visualization...")
            continue
        
        # Create masks map
        masks_map = {}
        for i, img_path in enumerate(file_list):
            mask_path = dataset._get_mask_path(img_path)
            mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
            mask = cv2.resize(mask, (model_cfg['img_size'], model_cfg['img_size']))
            masks_map[img_path] = (mask > 0).astype(np.uint8)
        
        print(f"\nDice Score Statistics for {model_cfg['name']}:")
        print(f"  Mean: {np.mean(dice_list):.4f}")
        print(f"  Std:  {np.std(dice_list):.4f}")
        print(f"  Min:  {np.min(dice_list):.4f}")
        print(f"  Max:  {np.max(dice_list):.4f}")
        print(f"  Median: {np.median(dice_list):.4f}")
        
        # Count non-zero predictions
        non_zero_preds = sum(1 for d in dice_list if d > 0)
        print(f"  Images with predictions: {non_zero_preds}/{len(dice_list)}")
        
        # Store results
        model_results.append({
            'name': model_cfg['name'],
            'file_list': file_list,
            'dice_list': dice_list,
            'preds_map': preds_map,
            'img_plot_map': img_plot_map,
            'masks_map': masks_map,
            'dataset': dataset
        })
    
    if len(model_results) == 0:
        raise RuntimeError("No models were successfully loaded. Check checkpoint paths and model architectures.")
    
    print(f"\n{'='*60}")
    print(f"Creating comparison visualizations...")
    print(f"{'='*60}")
    
    visualize_multi_model_comparison(model_results, model_results[0]['dataset'])
    
    print(f"\n{'='*60}")
    print(f"Done! Check overlay images in: {cfg.output_dir}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()